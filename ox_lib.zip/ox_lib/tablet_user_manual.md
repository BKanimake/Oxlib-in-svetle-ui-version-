# ox_lib Tablet UI System: User Manual & Developer Guide

The `ox_lib` Tablet UI is a modular, high-fidelity, and glassmorphic user interface. It allows developers to register **unique tablet configurations** (similar to context menus), render dynamic HTML templates, and route interaction events back to Lua.

---

## 1. Quick Start Guide for Players

1. **Accessing the Dev Menu**:
   - Open your game client console (F8 or chat box) and type `/checkuiox`.
   - A context menu will appear.
2. **Registering the Demo Tablet**:
   - Click option **12. Register Police Tablet Instance**. You will see a success notification.
3. **Opening the MDT**:
   - Click option **13. Open Police Tablet**. The LSPD Mobile Data Terminal will slide onto your screen and lock mouse focus.
4. **App Interaction**:
   - Navigate the home grid, select apps, and click buttons. Custom animations, progress wheels, and sound effects will play in-game when you trigger actions.
5. **Exiting**:
   - Click the physical **Home Button** on the bottom bezel, or click the **Shut Down** button on the Home Screen grid to release NUI focus.

---

## 2. Developer API Reference (Lua Client)

### `lib.registerTablet(config)`
Registers a unique tablet instance with its own custom branding and apps.

```lua
lib.registerTablet({
    id = 'ems_tablet',                        -- Unique identifier
    title = 'LS Medical Center',             -- Header title on home screen
    subtitle = 'Emergency Medical System',    -- Subtitle on home screen
    apps = {                                  -- Custom apps inside this tablet
        {
            id = 'triage',
            label = 'Triage Report',
            icon = 'fas fa-notes-medical',    -- FontAwesome icon class
            color = '#ff4757',                -- Accent theme color (swatch border)
            onSelect = function()
                -- Code run when this app is clicked
            end
        }
    }
})
```

---

### `lib.showTablet(tabletId)`
Opens the NUI device screen showing only the registered apps for that specific tablet ID.

```lua
lib.showTablet('ems_tablet')
```
*Note: If no ID is passed (i.e. `lib.showTablet()`), it defaults to the built-in system tablet (`system_tablet`).*

---

### `lib.setTabletAppContent(tabletId, appId, content)`
Injects custom HTML structures into the active application window.

```lua
lib.setTabletAppContent('ems_tablet', 'triage', {
    title = 'Triage Dashboard',
    html = [[
        <div style="padding:15px;">
            <h3>Diagnostics Panel</h3>
            <button data-action="stabilize" data-patient-id="15">Stabilize Patient</button>
        </div>
    ]]
})
```
*Note: Supports the backward-compatible signature `lib.setTabletAppContent(appId, content)` which defaults the tablet ID to `system_tablet`.*

---

### `lib.openTabletApp(tabletId, appId)`
Programmatically switches the tablet view directly to the specific app window.

```lua
lib.openTabletApp('ems_tablet', 'triage')
```

---

### `lib.hideTablet()`
Closes the tablet interface, resets NUI mouse/keyboard focus, and returns control to the player.

```lua
lib.hideTablet()
```

---

## 3. Designing Custom HTML Layouts & Click Triggers

### A. Styling Tokens
You can use standard CSS variables inside your injected HTML strings to match the active system theme and styling:
- `var(--primary-color)`: Matches the active settings primary accent color.
- `var(--text-color)`: Primary text color.
- `var(--text-muted)`: Soft gray color for labels and descriptors.
- `var(--success-color)`: Standard green theme.
- `var(--danger-color)`: Standard red theme.

### B. Binding Click Events (Data-Actions)
You do not need to write any JavaScript to handle clicks! Any element in your custom HTML that has a `data-action` attribute will automatically trigger click handlers:
```html
<button data-action="transfuse" data-bag-type="O-Negative" data-volume="500">Transfuse Blood</button>
```

When clicked, this posts a callback to Lua. The engine converts **all** `data-*` attributes on the clicked element into a camelCase payload object:
```json
{
  "bagType": "O-Negative",
  "volume": "500"
}
```

---

## 4. Handling App Events in Lua

When a player clicks a interactive element with a `data-action` inside your dynamic app, it triggers the following network/local events:

1. **App-Specific (Recommended)**:
   `ox_lib:tabletAppEvent:<tabletId>:<appId>`
   ```lua
   AddEventHandler('ox_lib:tabletAppEvent:ems_tablet:triage', function(action, payload)
       if action == 'stabilize' then
           print("Stabilizing patient ID: " .. payload.patientId)
       end
   end)
   ```

2. **Tablet-Specific**:
   `ox_lib:tabletAppEvent:<tabletId>`
   ```lua
   AddEventHandler('ox_lib:tabletAppEvent:ems_tablet', function(appId, action, payload)
       -- Handle events
   end)
   ```

3. **Generic**:
   `ox_lib:tabletAppEvent`
   ```lua
   AddEventHandler('ox_lib:tabletAppEvent', function(tabletId, appId, action, payload)
       -- Handle events
   end)
   ```

---

## 5. Complete Copy-Paste Demo Script

Here is a fully functional, stand-alone client script that you can add to **any** resource on your server to create a custom **EMS Medical Tablet**:

```lua
-- Register the custom EMS Tablet
lib.registerTablet({
    id = 'ems_tablet',
    title = 'Hospital MDT',
    subtitle = 'Los Santos Medical Console',
    apps = {
        {
            id = 'patient_triage',
            label = 'Triage Center',
            icon = 'fas fa-notes-medical',
            color = '#ff4757',
            onSelect = function()
                -- Load the initial layout
                lib.setTabletAppContent('ems_tablet', 'patient_triage', {
                    title = 'Emergency Triage',
                    html = [[
                        <div style="padding:15px;line-height:1.6;">
                            <p style="color:var(--text-muted);margin-bottom:12px;">Admitted ER patients logs.</p>
                            
                            <div style="display:flex;flex-direction:column;gap:8px;">
                                <div style="background:rgba(255,255,255,0.02);padding:12px;border-radius:6px;display:flex;justify-content:between;align-items:center;border:1px solid rgba(255,255,255,0.05);pointer-events:all !important;">
                                    <div>
                                        <span style="font-weight:700;display:block;">Jane Miller</span>
                                        <span style="font-size:0.75rem;color:var(--success-color);">Condition: Stable</span>
                                    </div>
                                    <button data-action="examine" data-name="Jane Miller" data-status="Stable" style="background:var(--primary-color);color:#fff;border:none;padding:5px 10px;border-radius:4px;cursor:pointer;pointer-events:all !important;">Examine</button>
                                </div>
                                <div style="background:rgba(255,255,255,0.02);padding:12px;border-radius:6px;display:flex;justify-content:between;align-items:center;border:1px solid rgba(255,255,255,0.05);pointer-events:all !important;">
                                    <div>
                                        <span style="font-weight:700;display:block;color:#ef4444;">Arthur Morgan</span>
                                        <span style="font-size:0.75rem;color:#ef4444;">Condition: Critical</span>
                                    </div>
                                    <button data-action="examine" data-name="Arthur Morgan" data-status="Critical" style="background:#ef4444;color:#fff;border:none;padding:5px 10px;border-radius:4px;cursor:pointer;pointer-events:all !important;">Examine</button>
                                </div>
                            </div>
                        </div>
                    ]]
                })
            end
        }
    }
})

-- Register a command to open the tablet
RegisterCommand('emstablet', function()
    lib.showTablet('ems_tablet')
end, false)

-- Handle the triage interactions
RegisterNetEvent('ox_lib:tabletAppEvent:ems_tablet:patient_triage', function(action, payload)
    if action == 'examine' then
        -- Close the tablet NUI focus while playing game animations
        lib.hideTablet()
        
        lib.notify({
            title = 'Medical Assessment',
            description = ('Initiating checkup on patient: %s...'):format(payload.name),
            type = 'info'
        })
        
        CreateThread(function()
            local success = lib.progressBar({
                duration = 4000,
                label = 'Diagnosing Vitals...',
                useWhileDead = false,
                canCancel = true,
                anim = {
                    dict = 'amb@medic@standing@tendtodead@idle_a',
                    clip = 'idle_a'
                }
            })
            if success then
                lib.notify({
                    title = 'Checkup Complete',
                    description = ('Patient %s is currently in %s condition.'):format(payload.name, payload.status),
                    type = payload.status == 'Critical' and 'error' or 'success',
                    duration = 5000
                })
            end
        end)
    end
end)
```

---

## 6. Cross-Resource Communication & Integration Guide

To use the tablet UI from a **completely separate resource** on your server (e.g. `esx_policejob` or `qb-police`), you must use FiveM exports and cross-resource event listeners.

### A. Calling Exports from External Resources
Always invoke the exports using `exports.ox_lib:<method>` instead of calling `lib.<method>` directly, to ensure correct namespace routing:

1. **Registering the Tablet**:
   ```lua
   exports.ox_lib:registerTablet({
       id = 'police_records',
       title = 'Police MDT',
       apps = {
           {
               id = 'warrants',
               label = 'Active Warrants',
               icon = 'fas fa-gavel',
               color = '#e74c3c'
           }
       }
   })
   ```

2. **Opening the Tablet**:
   ```lua
   exports.ox_lib:showTablet('police_records')
   ```

3. **Updating App HTML Content**:
   ```lua
   exports.ox_lib:setTabletAppContent('police_records', 'warrants', {
       title = 'Warrants List',
       html = '<button data-action="clear_warrant" data-id="1">Clear John Doe Warrant</button>'
   })
   ```

### B. Triggering Actions & Handling Callbacks Globally
When an action is clicked, `ox_lib` broadcasts a local event that any script on the server can listen to. To catch clicks in your separate resource, add a standard event handler:

```lua
-- In your separate script (e.g. my_police_script):
AddEventHandler('ox_lib:tabletAppEvent:police_records:warrants', function(action, payload)
    if action == 'clear_warrant' then
        -- Close the tablet first
        exports.ox_lib:hideTablet()
        
        -- Start clearing sequence in your script
        print("Clearing warrant ID: " .. payload.id)
    end
end)
```

---

## 7. Cross-Resource Demo: Dispatch Responder App

Here is an example of cross-resource communication. We have two separate scripts:
1. **`ox_lib`**: Manages NUI rendering and focus.
2. **`custom_dispatch`**: A completely separate script that registers the app, displays active dispatches, and sets waypoint maps on click.

### Complete `custom_dispatch` Client Script (`client.lua`):
```lua
-- 1. Register the custom MDT tablet under ID "lspd_dispatch"
exports.ox_lib:registerTablet({
    id = 'lspd_dispatch',
    title = '911 Emergency MDT',
    subtitle = 'LSPD Dispatch Terminal v1.0',
    apps = {
        {
            id = 'dispatch_logs',
            label = 'Emergency Logs',
            icon = 'fas fa-map-location-dot',
            color = '#3498db',
            onSelect = function()
                -- 2. When app is opened, set its HTML content
                exports.ox_lib:setTabletAppContent('lspd_dispatch', 'dispatch_logs', {
                    title = 'Active 911 Calls',
                    html = [[
                        <div style="padding:15px;line-height:1.6;">
                            <p style="color:var(--text-muted);margin-bottom:12px;">Active emergency calls on GPS radar.</p>
                            
                            <div style="display:flex;flex-direction:column;gap:10px;">
                                <div style="background:rgba(255,255,255,0.02);padding:15px;border-radius:8px;border:1px solid rgba(255,255,255,0.05);pointer-events:all !important;">
                                    <div style="font-weight:800;color:#e74c3c;"><i class="fas fa-gun"></i> 10-31: Shots Fired</div>
                                    <p style="font-size:0.8rem;color:var(--text-muted);margin:5px 0;">Location: Legion Square | Caller: Dispatch</p>
                                    <button data-action="set_waypoint" data-x="185.0" data-y="-920.0" data-label="Legion Square Shots" style="background:#e74c3c;color:#fff;border:none;padding:6px 12px;border-radius:4px;cursor:pointer;pointer-events:all !important;margin-top:5px;width:100%;">Set GPS Waypoint</button>
                                </div>
                                
                                <div style="background:rgba(255,255,255,0.02);padding:15px;border-radius:8px;border:1px solid rgba(255,255,255,0.05);pointer-events:all !important;">
                                    <div style="font-weight:800;color:#f1c40f;"><i class="fas fa-car-burst"></i> 10-50: Grand Theft Auto</div>
                                    <p style="font-size:0.8rem;color:var(--text-muted);margin:5px 0;">Location: LS Custom | Caller: Security Camera</p>
                                    <button data-action="set_waypoint" data-x="-350.0" data-y="-120.0" data-label="LS Customs Theft" style="background:var(--primary-color);color:#fff;border:none;padding:6px 12px;border-radius:4px;cursor:pointer;pointer-events:all !important;margin-top:5px;width:100%;">Set GPS Waypoint</button>
                                </div>
                            </div>
                        </div>
                    ]]
                })
            end
        }
    }
})

-- 3. Register command to open MDT
RegisterCommand('lspddispatch', function()
    exports.ox_lib:showTablet('lspd_dispatch')
end, false)

-- 4. Listen to dispatch click events in this separate script
AddEventHandler('ox_lib:tabletAppEvent:lspd_dispatch:dispatch_logs', function(action, payload)
    if action == 'set_waypoint' then
        -- Close the tablet UI
        exports.ox_lib:hideTablet()
        
        -- Parse GPS coordinates sent from HTML data attributes
        local posX = tonumber(payload.x)
        local posY = tonumber(payload.y)
        local label = tostring(payload.label)
        
        -- Setup waypoint on map
        SetNewWaypoint(posX, posY)
        
        exports.ox_lib:notify({
            title = 'MDT GPS System',
            description = ('Responding to %s. Route plotted on GPS!'):format(label),
            type = 'success',
            duration = 5000
        })
    end
end)
```

