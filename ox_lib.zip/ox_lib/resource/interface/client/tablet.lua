--[[
    https://github.com/overextended/ox_lib

    This file is licensed under LGPL-3.0 or higher <https://www.gnu.org/licenses/lgpl-3.0.en.html>

    Copyright © 2025 Linden <https://github.com/thelindat>
]]

local isOpen = false
local registeredTablets = {}

-- Setup default system tablet config for backward compatibility
local defaultSystemTablet = {
    id = 'system_tablet',
    title = 'OS X-TABLET',
    subtitle = 'Secure Operations System',
    apps = {
        { id = 'settings', label = 'Settings', icon = 'fas fa-sliders', color = '#3b82f6' },
        { id = 'players', label = 'Database', icon = 'fas fa-users', color = '#10b981' },
        { id = 'fingerprint', label = 'Scanner', icon = 'fas fa-fingerprint', color = '#8b5cf6' },
        { id = 'medical', label = 'Medical', icon = 'fas fa-heart-pulse', color = '#ef4444' }
    }
}
registeredTablets['system_tablet'] = defaultSystemTablet

---Registers a unique tablet configuration
---@class TabletProps
---@field id string Unique tablet identifier (like context menu ID)
---@field title string Branding title shown on Home Screen logo
---@field subtitle? string Branding subtitle shown below logo
---@field apps table[] List of apps in this tablet instance

---@param config TabletProps
function lib.registerTablet(config)
    if not config.id then
        return error("Cannot register tablet: Missing 'id'")
    end
    
    registeredTablets[config.id] = {
        id = config.id,
        title = config.title or 'OS X-TABLET',
        subtitle = config.subtitle or 'Operations Console',
        apps = config.apps or {}
    }
end

---Registers an app directly to the default system tablet (backward-compatible wrapper)
---@param app table
function lib.registerTabletApp(app)
    if not app.id then return end
    
    local system = registeredTablets['system_tablet']
    local foundIdx = nil
    for idx, existing in ipairs(system.apps) do
        if existing.id == app.id then
            foundIdx = idx
            break
        end
    end
    
    local appData = {
        id = app.id,
        label = app.label,
        icon = app.icon or 'fas fa-cubes',
        color = app.color or '#3b82f6',
        onSelect = app.onSelect
    }
    
    if foundIdx then
        system.apps[foundIdx] = appData
    else
        system.apps[#system.apps + 1] = appData
    end
end

---Opens a specific registered tablet UI instance
---@param tabletId string? If nil, falls back to the default 'system_tablet'
function lib.showTablet(tabletId)
    if isOpen then return end
    
    local activeId = tabletId or 'system_tablet'
    local tablet = registeredTablets[activeId]
    if not tablet then
        return error(("No registered tablet found with ID '%s'"):format(activeId))
    end
    
    isOpen = true
    lib.setNuiFocus(false) -- Lock focus, enable cursor, disable character movement
    
    -- Format apps structure to pass to NUI (stripping callbacks)
    local nuiApps = {}
    for _, app in ipairs(tablet.apps) do
        nuiApps[#nuiApps + 1] = {
            id = app.id,
            label = app.label,
            icon = app.icon,
            color = app.color
        }
    end
    
    SendNUIMessage({
        action = 'openTablet',
        data = {
            tabletId = tablet.id,
            title = tablet.title,
            subtitle = tablet.subtitle,
            apps = nuiApps
        }
    })
    
    TriggerEvent('bk_lib:tabletOpened', tablet.id)
    TriggerEvent('ox_lib:tabletOpened', tablet.id)
end

---Closes the currently active tablet UI
function lib.hideTablet()
    if not isOpen then return end
    isOpen = false

    lib.resetNuiFocus()
    SendNUIMessage({
        action = 'closeTablet'
    })
    
    TriggerEvent('bk_lib:tabletClosed')
    TriggerEvent('ox_lib:tabletClosed')
end

---Sets custom HTML content inside a tablet app body
---@param tabletId string
---@param appId string
---@param contentData {title: string, html: string}
function lib.setTabletAppContent(tabletId, appId, contentData)
    -- Support backward compatibility call: lib.setTabletAppContent(appId, contentData)
    if type(tabletId) ~= 'string' or not contentData then
        contentData = appId
        appId = tabletId
        tabletId = 'system_tablet'
    end
    
    SendNUIMessage({
        action = 'setTabletAppContent',
        data = {
            tabletId = tabletId,
            appId = appId,
            title = contentData.title,
            html = contentData.html
        }
    })
end

---Transition tablet view to the target application window
---@param tabletId string
---@param appId string
function lib.openTabletApp(tabletId, appId)
    -- Support backward compatibility call: lib.openTabletApp(appId)
    if not appId then
        appId = tabletId
        tabletId = 'system_tablet'
    end
    
    SendNUIMessage({
        action = 'openTabletApp',
        data = {
            tabletId = tabletId,
            appId = appId
        }
    })
end

-- -------------------------------------------------------------
-- NUI Callbacks
-- -------------------------------------------------------------

RegisterNUICallback('tabletClose', function(_, cb)
    cb(1)
    lib.hideTablet()
end)

RegisterNUICallback('tabletAction', function(data, cb)
    cb(1)
    
    -- Print action in client console for debugging/logs
    print(("^2[ox_lib]^7 Tablet Action from App: ^3%s^7 | Action: ^5%s^7"):format(tostring(data.app), tostring(data.action)))
    
    -- Trigger local events for custom script hooks
    TriggerEvent('bk_lib:tabletAction', data)
    TriggerEvent('ox_lib:tabletAction', data)
    
    -- Handle default system app events
    if data.app == 'settings' and data.action == 'themeChange' then
        TriggerEvent('bk_lib:tablet:themeChange', data.color, data.shade)
        TriggerEvent('ox_lib:tablet:themeChange', data.color, data.shade)
    elseif data.app == 'fingerprint' and data.action == 'matchFound' then
        TriggerEvent('bk_lib:tablet:fingerprintMatch', data.citizen)
        TriggerEvent('ox_lib:tablet:fingerprintMatch', data.citizen)
    elseif data.app == 'medical' then
        CreateThread(function()
            if data.action == 'extractBlood' then
                TriggerEvent('bk_lib:tablet:medicalAction', 'extract')
                TriggerEvent('ox_lib:tablet:medicalAction', 'extract')
            elseif data.action == 'transfuseBlood' then
                TriggerEvent('bk_lib:tablet:medicalAction', 'transfuse')
                TriggerEvent('ox_lib:tablet:medicalAction', 'transfuse')
            end
        end)
    end
end)

-- Callback when home screen app is clicked
RegisterNUICallback('tabletAppSelect', function(data, cb)
    cb(1)
    local tabletId = data.tabletId or 'system_tablet'
    local appId = data.appId
    
    local tablet = registeredTablets[tabletId]
    if tablet then
        -- Find the app configuration to extract selection callback
        local targetApp = nil
        for _, app in ipairs(tablet.apps) do
            if app.id == appId then
                targetApp = app
                break
            end
        end
        
        if targetApp then
            if targetApp.onSelect then
                CreateThread(function()
                    targetApp.onSelect()
                end)
            else
                lib.openTabletApp(tabletId, appId)
            end
        end
    end
end)

-- Callback when custom element with data-action is clicked inside custom HTML content
RegisterNUICallback('tabletAppEvent', function(data, cb)
    cb(1)
    local tabletId = data.tabletId or 'system_tablet'
    
    -- Trigger generic event
    TriggerEvent('bk_lib:tabletAppEvent', tabletId, data.appId, data.action, data.payload)
    TriggerEvent('ox_lib:tabletAppEvent', tabletId, data.appId, data.action, data.payload)
    -- Trigger tablet-specific event
    TriggerEvent(('bk_lib:tabletAppEvent:%s'):format(tabletId), data.appId, data.action, data.payload)
    TriggerEvent(('ox_lib:tabletAppEvent:%s'):format(tabletId), data.appId, data.action, data.payload)
    -- Trigger app-specific event
    TriggerEvent(('bk_lib:tabletAppEvent:%s:%s'):format(tabletId, data.appId), data.action, data.payload)
    TriggerEvent(('ox_lib:tabletAppEvent:%s:%s'):format(tabletId, data.appId), data.action, data.payload)
end)

RegisterNetEvent('ox_lib:showTablet', lib.showTablet)
RegisterNetEvent('ox_lib:hideTablet', lib.hideTablet)
RegisterNetEvent('bk_lib:showTablet', lib.showTablet)
RegisterNetEvent('bk_lib:hideTablet', lib.hideTablet)
