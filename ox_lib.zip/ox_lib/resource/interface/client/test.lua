--[[
    UI Test Commands for ox_lib Vanilla UI
    Command: /checkuiox
]]

-- Sub-menu for nested context menu tests
lib.registerContext({
    id = 'ox_lib_ui_tests_submenu',
    title = 'Sub-Menu Tests',
    menu = 'ox_lib_ui_tests',
    options = {
        {
            title = 'Test Success Notify',
            description = 'Triggers a success notification',
            icon = 'check-circle',
            iconColor = '#10b981',
            onSelect = function()
                lib.notify({
                    title = 'Sub-Menu Test',
                    description = 'Successfully triggered from nested menu!',
                    type = 'success'
                })
            end
        },
        {
            title = 'Test Error Notify',
            description = 'Triggers an error notification',
            icon = 'circle-xmark',
            iconColor = '#ef4444',
            onSelect = function()
                lib.notify({
                    title = 'Sub-Menu Test',
                    description = 'Error test notification!',
                    type = 'error'
                })
            end
        }
    }
})

-- Main Context Menu registration
lib.registerContext({
    id = 'ox_lib_ui_tests',
    title = 'ox_lib Vanilla UI Tester',
    options = {
        {
            title = '1. Test Notification',
            description = 'Send a test notification to the top-right',
            icon = 'bell',
            iconColor = '#3b82f6',
            onSelect = function()
                lib.notify({
                    title = 'UI Test Notification',
                    description = 'This is a premium, backdrop-filter free notification!',
                    type = 'info',
                    position = 'top-right',
                    duration = 5000
                })
            end
        },
        {
            title = '2. Test Alert Dialog',
            description = 'Trigger a confirm / cancel dialog modal',
            icon = 'circle-question',
            iconColor = '#f59e0b',
            onSelect = function()
                CreateThread(function()
                    local alert = lib.alertDialog({
                        header = 'Confirm UI Test',
                        content = 'Does the new vanilla UI look clean and perform well?',
                        centered = true,
                        cancel = true
                    })
                    if alert == 'confirm' then
                        lib.notify({ title = 'Alert Result', description = 'You clicked Confirm!', type = 'success' })
                    else
                        lib.notify({ title = 'Alert Result', description = 'You clicked Cancel / Closed', type = 'error' })
                    end
                end)
            end
        },
        {
            title = '3. Open nested sub-menu',
            description = 'Test context menu back/forward navigation',
            icon = 'arrow-right-to-bracket',
            iconColor = '#06b6d4',
            menu = 'ox_lib_ui_tests_submenu'
        },
        {
            title = '4. Test Input Dialog',
            description = 'Trigger a form dialog with text, slider, and dropdown',
            icon = 'pen-to-square',
            iconColor = '#8b5cf6',
            onSelect = function()
                CreateThread(function()
                    local input = lib.inputDialog('Test Form Inputs', {
                        { type = 'input', label = 'Your Name', placeholder = 'Enter name...', required = true },
                        { type = 'slider', label = 'Age', min = 18, max = 100, default = 25 },
                        { type = 'checkbox', label = 'Accept Terms', checked = false },
                        { type = 'select', label = 'Preferred Vehicle', options = {
                            { value = 'adder', label = 'Adder Supercar' },
                            { value = 'sultan', label = 'Sultan Classic' },
                            { value = 'bmx', label = 'BMX Bike' }
                        }}
                    })
                    if input then
                        lib.notify({
                            title = 'Form Submitted',
                            description = ('Name: %s, Age: %d, Accepted: %s, Vehicle: %s'):format(input[1], input[2], tostring(input[3]), input[4]),
                            type = 'success',
                            duration = 7000
                        })
                    else
                        lib.notify({ title = 'Form Cancelled', description = 'You closed the input dialog.', type = 'error' })
                    end
                end)
            end
        },
        {
            title = '5. Test Keyboard Menu',
            description = 'Trigger a standard menu list supporting arrow keys',
            icon = 'keyboard',
            iconColor = '#ec4899',
            onSelect = function()
                lib.registerMenu({
                    id = 'test_keyboard_menu',
                    title = 'Keyboard Menu Test',
                    position = 'top-left',
                    options = {
                        { label = 'Notify Option', description = 'Click to show notify' },
                        { label = 'Disabled Option', description = 'This option is disabled', disabled = true },
                        { label = 'Checkable Option', checked = true, description = 'This option can be checked' }
                    }
                }, function(selected, scrollIndex, args)
                    lib.notify({
                        title = 'Menu Clicked',
                        description = ('Selected Index: %s, checked/scroll: %s'):format(tostring(selected), tostring(scrollIndex)),
                        type = 'info'
                    })
                end)
                lib.showMenu('test_keyboard_menu')
            end
        },
        {
            title = '6. Test Progress Bar (Linear)',
            description = 'Trigger a linear progress bar (5 seconds)',
            icon = 'spinner',
            iconColor = '#10b981',
            onSelect = function()
                CreateThread(function()
                    if lib.progressBar({
                        duration = 5000,
                        label = 'Downloading system patches...',
                        useWhileDead = false,
                        canCancel = true,
                        icon = 'download',
                        color = 'linear-gradient(90deg, #ec4899, #8b5cf6)',
                        position = 'bottom',
                        disable = {
                            car = true,
                            move = true
                        }
                    }) then
                        lib.notify({ title = 'Progress Result', description = 'Successfully completed!', type = 'success' })
                    else
                        lib.notify({ title = 'Progress Result', description = 'Progress cancelled!', type = 'error' })
                    end
                end)
            end
        },
        {
            title = '7. Test Progress Circle',
            description = 'Trigger a circular progress overlay (3 seconds)',
            icon = 'rotate',
            iconColor = '#14b8a6',
            onSelect = function()
                CreateThread(function()
                    if lib.progressCircle({
                        duration = 3000,
                        label = 'Securing area database...',
                        position = 'bottom',
                        icon = 'lock',
                        color = '#14b8a6',
                        useWhileDead = false,
                        canCancel = true
                    }) then
                        lib.notify({ title = 'Progress Result', description = 'Circle progress completed!', type = 'success' })
                    else
                        lib.notify({ title = 'Progress Result', description = 'Circle progress cancelled!', type = 'error' })
                    end
                end)
            end
        },
        {
            title = '8. Test Radial Menu',
            description = 'Trigger a circular radial overlay wheel',
            icon = 'dharmachakra',
            iconColor = '#eab308',
            onSelect = function()
                lib.addRadialItem({
                    {
                        id = 'test_radial_1',
                        label = 'Option A',
                        icon = 'star',
                        onSelect = function()
                            lib.notify({ title = 'Radial Click', description = 'Selected Option A', type = 'info' })
                        end
                    },
                    {
                        id = 'test_radial_2',
                        label = 'Option B',
                        icon = 'heart',
                        onSelect = function()
                            lib.notify({ title = 'Radial Click', description = 'Selected Option B', type = 'info' })
                        end
                    }
                })
                lib.notify({ title = 'Radial Menu', description = 'Open your radial menu in game to test!', type = 'info' })
            end
        },
        {
            title = '9. Test Skill Check',
            description = 'Trigger a skill check minigame',
            icon = 'bullseye',
            iconColor = '#f43f5e',
            onSelect = function()
                CreateThread(function()
                    local success = lib.skillCheck({'easy', 'easy'}, {'e'})
                    if success then
                        lib.notify({ title = 'Skill Check', description = 'Success! Brilliant timing.', type = 'success' })
                    else
                        lib.notify({ title = 'Skill Check', description = 'Failed! Try again.', type = 'error' })
                    end
                end)
            end
        },
        {
            title = '10. Test Text UI',
            description = 'Toggle a Text UI label for 5 seconds',
            icon = 'message',
            iconColor = '#f97316',
            onSelect = function()
                lib.showTextUI('[E] - Access Terminal', {
                    position = 'right-center',
                    icon = 'terminal',
                    style = {
                        borderRadius = 10,
                        backgroundColor = '#111827',
                        color = '#fff'
                    }
                })
                SetTimeout(5000, function()
                    lib.hideTextUI()
                    lib.notify({ title = 'Text UI', description = 'Text UI closed after 5s', type = 'info' })
                end)
            end
        },
        {
            title = '11. Test Tablet UI',
            description = 'Open the new premium tablet UI containing utility apps',
            icon = 'tablet-screen-button',
            iconColor = '#10b981',
            onSelect = function()
                CreateThread(function()
                    lib.showTablet()
                end)
            end
        },
        {
            title = '12. Register Police Tablet Instance',
            description = 'Simulate an external script registering a custom "police_tablet" instance',
            icon = 'building-shield',
            iconColor = '#1e3799',
            onSelect = function()
                lib.registerTablet({
                    id = 'police_tablet',
                    title = 'LSPD Terminal',
                    subtitle = 'Mobile Data Terminal v2.1',
                    apps = {
                        {
                            id = 'police_records',
                            label = 'Criminal Database',
                            icon = 'fas fa-users-line',
                            color = '#1e3799',
                            onSelect = function()
                                lib.setTabletAppContent('police_tablet', 'police_records', {
                                    title = 'LSPD Records Search',
                                    html = [[
                                        <div style="padding:15px;line-height:1.6;">
                                            <p style="margin-bottom:15px;color:var(--text-muted);">Welcome to the LSPD records terminal.</p>
                                            <div class="player-list" style="display:flex;flex-direction:column;gap:10px;">
                                                <div class="player-item" style="background:rgba(255,255,255,0.02);padding:10px 15px;border-radius:8px;display:flex;justify-content:between;align-items:center;border:1px solid rgba(255,255,255,0.05);pointer-events:all !important;">
                                                    <div style="text-align:left;">
                                                        <span style="font-weight:700;display:block;color:var(--primary-color);">John Doe</span>
                                                        <span style="font-size:0.75rem;color:var(--text-muted);">Status: Warrants Outstanding</span>
                                                    </div>
                                                    <button class="player-btn-view" data-action="arrest" data-name="John Doe" style="background:#ef4444;color:#fff;border:none;padding:5px 10px;border-radius:5px;cursor:pointer;pointer-events:all !important;">Issue Arrest</button>
                                                </div>
                                                <div class="player-item" style="background:rgba(255,255,255,0.02);padding:10px 15px;border-radius:8px;display:flex;justify-content:between;align-items:center;border:1px solid rgba(255,255,255,0.05);pointer-events:all !important;">
                                                    <div style="text-align:left;">
                                                        <span style="font-weight:700;display:block;color:var(--primary-color);">Sarah Smith</span>
                                                        <span style="font-size:0.75rem;color:var(--text-muted);">Status: Clean Record</span>
                                                    </div>
                                                    <button class="player-btn-view" data-action="citation" data-name="Sarah Smith" style="background:var(--primary-color);color:#fff;border:none;padding:5px 10px;border-radius:5px;cursor:pointer;pointer-events:all !important;">Issue Citation</button>
                                                </div>
                                            </div>
                                        </div>
                                    ]]
                                })
                            end
                        },
                        {
                            id = 'police_mdt',
                            label = 'MDT Dispatches',
                            icon = 'fas fa-circle-exclamation',
                            color = '#f8c291',
                            onSelect = function()
                                lib.setTabletAppContent('police_tablet', 'police_mdt', {
                                    title = 'Active 911 Dispatches',
                                    html = [[
                                        <div style="padding:15px;line-height:1.6;">
                                            <p style="margin-bottom:15px;color:var(--text-muted);">Active emergency dispatches.</p>
                                            <div style="background:rgba(234,179,8,0.08);border:1px solid rgba(234,179,8,0.25);border-radius:10px;padding:15px;line-height:1.6;pointer-events:all !important;">
                                                <div style="font-weight:800;color:#eab308;margin-bottom:6px;"><i class="fas fa-triangle-exclamation"></i> 10-99: Armed Robbery in Progress</div>
                                                <p><strong>Location:</strong> Maze Bank West</p>
                                                <button class="scanner-btn" data-action="respond_dispatch" data-dispatch-id="1099" style="width:100%;margin-top:10px;padding:8px;background:var(--primary-color);color:#fff;border:none;border-radius:6px;cursor:pointer;pointer-events:all !important;">Respond (Set Waypoint)</button>
                                            </div>
                                        </div>
                                    ]]
                                })
                            end
                        }
                    }
                })
                lib.notify({
                    title = 'Developer Simulator',
                    description = 'Successfully registered "police_tablet" instance! You can now open it.',
                    type = 'success'
                })
            end
        },
        {
            title = '13. Open Police Tablet',
            description = 'Open the registered "police_tablet" instance with its own custom MDT branding',
            icon = 'tablet',
            iconColor = '#1e3799',
            onSelect = function()
                CreateThread(function()
                    lib.showTablet('police_tablet')
                end)
            end
        }
    }
})

-- Register client command to open the menu
RegisterCommand('checkuiox', function()
    lib.showContext('ox_lib_ui_tests')
end, false)

-- Handlers for tablet actions (Settings, Fingerprint, Medical)
RegisterNetEvent('ox_lib:tablet:themeChange', function(color, shade)
    lib.notify({
        title = 'System Settings',
        description = ('Theme color set to %s (%s)'):format(shade, color),
        type = 'info'
    })
end)

RegisterNetEvent('ox_lib:tablet:fingerprintMatch', function(citizenName)
    lib.notify({
        title = 'Bio-Scanner',
        description = ('Fingerprint matches citizen: %s'):format(citizenName),
        type = 'success'
    })
end)

RegisterNetEvent('ox_lib:tablet:medicalAction', function(action)
    if action == 'extract' then
        CreateThread(function()
            lib.notify({
                title = 'Medical App',
                description = 'Targeting nearest patient for blood extraction...',
                type = 'info'
            })
            Wait(1500)
            local success = lib.progressBar({
                duration = 5000,
                label = 'Extracting Blood Sample...',
                useWhileDead = false,
                canCancel = true,
                disable = {
                    move = true,
                    car = true
                },
                anim = {
                    dict = 'amb@medic@standing@tendtodead@idle_a',
                    clip = 'idle_a'
                }
            })
            if success then
                lib.notify({
                    title = 'Medical App',
                    description = 'Blood extracted successfully! Received Blood Bag.',
                    type = 'success'
                })
            else
                lib.notify({
                    title = 'Medical App',
                    description = 'Extraction cancelled.',
                    type = 'error'
                })
            end
        end)
    elseif action == 'transfuse' then
        CreateThread(function()
            lib.notify({
                title = 'Medical App',
                description = 'Preparing blood transfusion setup...',
                type = 'info'
            })
            Wait(1500)
            local success = lib.progressBar({
                duration = 6000,
                label = 'Transfusing Blood...',
                useWhileDead = false,
                canCancel = true,
                disable = {
                    move = true,
                    car = true
                },
                anim = {
                    dict = 'amb@medic@standing@tendtodead@idle_a',
                    clip = 'idle_a'
                }
            })
            if success then
                lib.notify({
                    title = 'Medical App',
                    description = 'Transfusion complete! Patient health restored.',
                    type = 'success'
                })
            else
                lib.notify({
                    title = 'Medical App',
                    description = 'Transfusion cancelled.',
                    type = 'error'
                })
            end
        end)
    end
end)

-- Handlers for custom police tablet instance events
RegisterNetEvent('ox_lib:tabletAppEvent:police_tablet', function(appId, action, payload)
    if appId == 'police_records' then
        if action == 'arrest' then
            lib.notify({
                title = 'LSPD Records',
                description = ('Preparing arrest warrant file for %s...'):format(payload.name),
                type = 'warning'
            })
            CreateThread(function()
                if lib.progressCircle({
                    duration = 3000,
                    label = 'Filing Arrest Warrant...',
                    position = 'bottom',
                    canCancel = true
                }) then
                    lib.notify({
                        title = 'LSPD Records',
                        description = ('Arrest warrant successfully issued for %s!'):format(payload.name),
                        type = 'success'
                    })
                end
            end)
        elseif action == 'citation' then
            lib.notify({
                title = 'LSPD Records',
                description = ('Filing citation for %s...'):format(payload.name),
                type = 'info'
            })
            CreateThread(function()
                Wait(1500)
                lib.notify({
                    title = 'LSPD Records',
                    description = ('Citation issued successfully to %s.'):format(payload.name),
                    type = 'success'
                })
            end)
        end
    elseif appId == 'police_mdt' then
        if action == 'respond_dispatch' then
            lib.notify({
                title = 'LSPD Dispatch',
                description = ('Responding to dispatch ID: %s...'):format(payload.dispatchId),
                type = 'info'
            })
            CreateThread(function()
                if lib.progressCircle({
                    duration = 2000,
                    label = 'Plotting GPS Waypoint...',
                    position = 'bottom',
                    canCancel = false
                }) then
                    PlaySoundFrontend(-1, "Menu_Accept", "Phone_SoundSet_Default", 1)
                    lib.notify({
                        title = 'LSPD Dispatch',
                        description = 'GPS waypoint set to Maze Bank West. Unit responding.',
                        type = 'success'
                    })
                end
            end)
        end
    end
end)

