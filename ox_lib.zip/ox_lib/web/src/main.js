import { mount } from 'svelte';
import App from './App.svelte';
import './styles/index.css';
import './styles/okok_theme.css';

const app = mount(App, {
  target: document.getElementById('app'),
});

export default app;
