<script>
  import { onMount, onDestroy } from 'svelte';

  let { contextConfig, post, contextUnlocked = $bindable(), onclose } = $props();

  let scanProgress = $state('idle'); // 'idle' | 'scanning' | 'success'
  let scanStatusText = $state('Browser Scan Required');
  let scanStatusSub = $state('Waiting for biometric scan...');
  let phoneTime = $state('09:41 AM');
  let timeTimer;

  $effect(() => {
    if (contextConfig) {
      scanProgress = 'idle';
      scanStatusText = 'Browser Scan Required';
      scanStatusSub = 'Waiting for biometric scan...';
    }
  });

  // Render Time
  const updatePhoneTime = () => {
    const date = new Date();
    let hours = date.getHours();
    let minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    minutes = minutes < 10 ? '0' + minutes : minutes;
    phoneTime = hours + ':' + minutes + ' ' + ampm;
  };

  onMount(() => {
    updatePhoneTime();
    timeTimer = setInterval(updatePhoneTime, 30000);

    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        handleClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      clearInterval(timeTimer);
      window.removeEventListener('keydown', handleKeyDown);
    };
  });

  const handleClose = (notifyServer = true) => {
    if (notifyServer) {
      post('closeContext');
      contextUnlocked = false;
    }
    onclose();
  };

  const handleBack = () => {
    post('openContext', { id: contextConfig.menu, back: true });
  };

  const handleScan = () => {
    if (scanProgress !== 'idle') return;
    scanProgress = 'scanning';
    scanStatusText = 'Verifying...';
    scanStatusSub = 'Scanning browser credentials...';

    setTimeout(() => {
      scanProgress = 'success';
      scanStatusText = 'Unlocked!';
      scanStatusSub = 'Browser Unlocked!';

      setTimeout(() => {
        contextUnlocked = true;
      }, 500);
    }, 1500);
  };

  const handleOptionClick = (key, opt) => {
    if (opt.disabled || opt.readOnly) return;
    if (opt.menu) {
      post('openContext', { id: opt.menu });
    } else {
      handleClose(false);
      post('clickContext', key);
    }
  };

  // Helper for rendering icons
  const getIconClass = (icon) => {
    if (!icon) return '';
    if (typeof icon === 'string') {
      return icon.startsWith('fa-') || icon.includes(' ') ? (icon.includes(' ') ? icon : `fas ${icon}`) : `fas fa-${icon}`;
    } else if (Array.isArray(icon)) {
      const style = icon[0] || 'fas';
      const name = icon[1] ? (icon[1].startsWith('fa-') ? icon[1] : `fa-${icon[1]}`) : '';
      return `${style} ${name}`;
    }
    return '';
  };

  const options = $derived(contextConfig.options || []);
  const entries = $derived(
    Array.isArray(options) ? options.map((v, i) => [i, v]) : Object.entries(options)
  );
</script>

<!-- svelte-ignore a11y_click_events_have_key_events -->
<!-- svelte-ignore a11y_no_static_element_interactions -->
<div id="context-container" class="overlay-container active" onclick={() => contextConfig.canClose !== false && handleClose()}>
  <div id="context-phone-frame" class="pointer-all" onclick={(e) => e.stopPropagation()}>
    <!-- notch -->
    <div id="context-phone-notch"></div>

    <div id="context-phone-screen">
      <!-- Status Bar -->
      <div id="context-phone-status-bar">
        <div class="status-left">
          <span id="context-phone-wifi-icon"><i class="fas fa-wifi"></i></span>
          <span id="context-phone-network">5G</span>
        </div>
        <div class="status-center">
          <span id="context-phone-time">{phoneTime}</span>
        </div>
        <div class="status-right">
          <span id="context-phone-battery-percent">100%</span>
          <span id="context-phone-battery-icon"><i class="fas fa-battery-full"></i></span>
        </div>
      </div>

      {#if !contextUnlocked}
        <!-- Scanner View -->
        <div id="context-scanner-view" class="context-phone-view active">
          <div class="phone-app-header">
            <div id="context-scanner-title">Web Browser Unlock</div>
          </div>
          <div class="phone-scanner-content">
            <div id="context-phone-scanner-area" class="phone-scanner-area {scanProgress}">
              <div class="phone-scanner-laser"></div>
              <div class="phone-scanner-icon">
                {#if scanProgress === 'success'}
                  <i class="fas fa-circle-check"></i>
                {:else}
                  <i class="fas fa-fingerprint"></i>
                {/if}
              </div>
            </div>
            <div class="phone-scanner-instructions">{scanStatusText}</div>
            <button 
              id="context-phone-scan-btn" 
              class="phone-scanner-btn {scanProgress !== 'idle' ? 'disabled' : ''}" 
              onclick={handleScan}
            >
              {scanProgress === 'scanning' ? 'Verifying...' : scanProgress === 'success' ? 'Unlocked!' : 'Scan to Unlock'}
            </button>
            <div 
              id="context-phone-scan-status"
              style="color: {scanProgress === 'scanning' ? 'var(--primary-color)' : scanProgress === 'success' ? 'var(--success-color)' : 'var(--text-muted)'}"
            >
              {scanStatusSub}
            </div>
          </div>
        </div>
      {:else}
        <!-- Menu View -->
        <div id="context-menu-view" class="context-phone-view active">
          <div id="context-header">
            {#if contextConfig.menu}
              <div id="context-back-btn" class="context-back-btn pointer-all" onclick={handleBack}>
                <i class="fas fa-chevron-left"></i>
              </div>
            {:else}
              <div style="width:30px"></div>
            {/if}
            <div id="context-title">{contextConfig.title || 'Menu'}</div>
            {#if contextConfig.canClose !== false}
              <div id="context-close-btn" class="context-close-btn pointer-all" onclick={() => handleClose()}>
                <i class="fas fa-xmark"></i>
              </div>
            {:else}
              <div style="width:30px"></div>
            {/if}
          </div>

          <div id="context-options" class="scroll-y">
            {#each entries as [key, opt]}
              <!-- svelte-ignore a11y_click_events_have_key_events -->
              <div 
                class="context-option-card {opt.disabled ? 'disabled' : ''} {(opt.readOnly || (!opt.hasAction && !opt.menu)) ? 'read-only' : ''} pointer-all"
                onclick={() => handleOptionClick(key, opt)}
              >
                <div class="context-option-top">
                  {#if opt.icon}
                    <div class="context-option-icon">
                      <i class={getIconClass(opt.icon)} style={opt.iconColor ? `color:${opt.iconColor}` : ''}></i>
                    </div>
                  {/if}
                  <div class="context-option-title">{opt.title || ''}</div>
                  {#if opt.arrow !== false && (opt.menu || opt.onSelect || opt.event || opt.serverEvent)}
                    <div class="context-option-arrow"><i class="fas fa-chevron-right"></i></div>
                  {/if}
                </div>

                {#if opt.description}
                  <div class="context-option-desc">{opt.description}</div>
                {/if}

                {#if opt.image}
                  <img src={opt.image} class="context-option-image" alt="option-img" />
                {/if}

                {#if opt.metadata}
                  <div class="context-option-metadata">
                    {#if Array.isArray(opt.metadata)}
                      {#each opt.metadata as val}
                        <div class="metadata-row">
                          <span class="metadata-val">{val}</span>
                        </div>
                      {/each}
                    {:else}
                      {#each Object.entries(opt.metadata) as [lbl, val]}
                        <div class="metadata-row">
                          <span class="metadata-label">{lbl}</span>
                          <span class="metadata-val">{val}</span>
                        </div>
                      {/each}
                    {/if}
                  </div>
                {/if}

                {#if opt.progress !== undefined && opt.progress !== null}
                  <div class="context-option-progress" style="width: {opt.progress}%"></div>
                {/if}
              </div>
            {/each}
          </div>
        </div>
      {/if}
    </div>

    <!-- Home Indicator -->
    <div id="context-phone-home-indicator"></div>
  </div>
</div>
