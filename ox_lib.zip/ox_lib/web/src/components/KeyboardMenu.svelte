<script>
  import { onMount, tick } from 'svelte';

  let { keyboardMenuConfig, post, onclose } = $props();

  let items = $state([]);
  let selectedIndex = $state(0);
  let menuCanClose = $state(true);
  let optionsContainer = $state(null);

  $effect(() => {
    if (keyboardMenuConfig) {
      items = keyboardMenuConfig.items || [];
      selectedIndex = keyboardMenuConfig.startItemIndex || 0;
      menuCanClose = keyboardMenuConfig.canClose !== false;
      scrollToSelected();
    }
  });

  onMount(() => {

    const handleKeyDown = (e) => {
      const activeOption = items[selectedIndex];

      switch(e.key) {
        case 'ArrowUp':
          e.preventDefault();
          let prevIdx = selectedIndex;
          do {
            selectedIndex = (selectedIndex - 1 + items.length) % items.length;
          } while (items[selectedIndex]?.disabled && selectedIndex !== prevIdx);
          handleSelectionChange();
          break;

        case 'ArrowDown':
          e.preventDefault();
          let nextIdx = selectedIndex;
          do {
            selectedIndex = (selectedIndex + 1) % items.length;
          } while (items[selectedIndex]?.disabled && selectedIndex !== nextIdx);
          handleSelectionChange();
          break;

        case 'ArrowLeft':
          if (activeOption && activeOption.values) {
            e.preventDefault();
            shiftScrollIndex(selectedIndex, true);
          }
          break;

        case 'ArrowRight':
          if (activeOption && activeOption.values) {
            e.preventDefault();
            shiftScrollIndex(selectedIndex, false);
          }
          break;

        case 'Enter':
          e.preventDefault();
          if (activeOption && !activeOption.disabled) {
            if (activeOption.checked !== undefined) {
              toggleCheckbox(selectedIndex);
            } else {
              confirmSelection();
            }
          }
          break;

        case 'Escape':
        case 'Backspace':
          if (menuCanClose) {
            e.preventDefault();
            handleClose(e.key);
          }
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  });

  const handleClose = (keyPressed = null, notifyServer = true) => {
    if (notifyServer) {
      post('closeMenu', keyPressed);
    }
    onclose();
  };

  const handleSelectionChange = () => {
    scrollToSelected();
    const opt = items[selectedIndex];
    if (opt) {
      const scrollIdx = opt.values ? (opt.defaultIndex || 0) : null;
      const isCheck = opt.checked !== undefined;
      post('changeSelected', [selectedIndex, scrollIdx, isCheck]);
    }
  };

  const scrollToSelected = async () => {
    await tick();
    if (optionsContainer) {
      const selectedNode = optionsContainer.children[selectedIndex];
      if (selectedNode) {
        selectedNode.scrollIntoView({ block: 'nearest' });
      }
    }
  };

  const shiftScrollIndex = (itemIdx, isLeft) => {
    const opt = items[itemIdx];
    if (!opt || !opt.values || opt.values.length === 0) return;

    let currentIdx = opt.defaultIndex || 0;
    if (isLeft) {
      currentIdx = (currentIdx - 1 + opt.values.length) % opt.values.length;
    } else {
      currentIdx = (currentIdx + 1) % opt.values.length;
    }
    items[itemIdx].defaultIndex = currentIdx;
    
    post('changeIndex', [itemIdx, currentIdx]);
  };

  const toggleCheckbox = (itemIdx) => {
    const opt = items[itemIdx];
    if (!opt || opt.checked === undefined) return;

    items[itemIdx].checked = !opt.checked;
    post('changeChecked', [itemIdx, items[itemIdx].checked]);
  };

  const confirmSelection = () => {
    const opt = items[selectedIndex];
    if (!opt || opt.disabled) return;

    const scrollIdx = opt.values ? (opt.defaultIndex || 0) : null;
    const isChecked = opt.checked !== undefined ? opt.checked : null;

    if (opt.close !== false) {
      handleClose(null, false);
    }

    post('confirmSelected', [selectedIndex, scrollIdx, isChecked]);
  };

  const handleItemClick = (index, opt, e) => {
    if (opt.disabled) return;

    // Check if scroll arrow was clicked
    if (e.target.classList.contains('menu-scroll-arrow')) {
      const isLeft = e.target.classList.contains('left');
      shiftScrollIndex(index, isLeft);
      return;
    }

    selectedIndex = index;
    handleSelectionChange();

    if (opt.checked !== undefined) {
      toggleCheckbox(index);
    } else {
      confirmSelection();
    }
  };

  // Helper for rendering icons
  const getIconClass = (icon) => {
    if (!icon) return '';
    if (typeof icon === 'string') {
      return icon.startsWith('fa-') || icon.includes(' ') ? (icon.includes(' ') ? icon : `fas ${icon}`) : `fas fa-${icon}`;
    } else if (Array.isArray(icon)) {
      const style = icon[0] || 'fas';
      const name = icon[1] ? (icon[1].startsWith('fa-') ? icon[1] : `fa-${icon[1]}`) : '';
      return `${style} ${name}`;
    }
    return '';
  };
</script>

<!-- svelte-ignore a11y_click_events_have_key_events -->
<!-- svelte-ignore a11y_no_static_element_interactions -->
<div id="menu-container" class="overlay-container active" onclick={() => menuCanClose && handleClose('Escape')}>
  <div id="keyboard-menu" class="pointer-all menu-{keyboardMenuConfig.position || 'top-left'}" onclick={(e) => e.stopPropagation()}>
    <div id="menu-header">{keyboardMenuConfig.title || 'Menu'}</div>
    
    <div id="menu-options" class="scroll-y" bind:this={optionsContainer}>
      {#each items as opt, index}
        {@const isSelected = index === selectedIndex}
        <div 
          class="menu-option-item {isSelected ? 'selected' : ''} {opt.disabled ? 'disabled' : ''} pointer-all"
          onclick={(e) => handleItemClick(index, opt, e)}
        >
          <!-- Option Icon -->
          {#if opt.icon}
            <div class="menu-item-icon">
              <i class={getIconClass(opt.icon)} style={opt.iconColor ? `color:${opt.iconColor}` : ''}></i>
            </div>
          {/if}

          <!-- Option Content -->
          <div class="menu-item-body">
            <div class="menu-item-label">{opt.label || ''}</div>
            {#if opt.description}
              <div class="menu-item-desc">{opt.description}</div>
            {/if}
          </div>

          <!-- Option Value Scroller or Checkbox -->
          {#if opt.values && opt.values.length > 0}
            {@const sIdx = opt.defaultIndex || 0}
            {@const valStr = typeof opt.values[sIdx] === 'object' ? opt.values[sIdx].label : opt.values[sIdx]}
            <div class="menu-item-scroll">
              <i class="fas fa-chevron-left menu-scroll-arrow left"></i>
              <span>{valStr}</span>
              <i class="fas fa-chevron-right menu-scroll-arrow right"></i>
            </div>
          {:else if opt.checked !== undefined}
            <div class="menu-item-checkbox {opt.checked ? 'checked' : ''}">
              <i class="fas fa-check"></i>
            </div>
          {/if}

          <!-- Progress Bar inside Option -->
          {#if opt.progress !== undefined}
            <div class="menu-item-progress-bar" style="width: {opt.progress}%"></div>
          {/if}
        </div>
      {/each}
    </div>
  </div>
</div>
