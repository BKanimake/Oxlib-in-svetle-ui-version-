<script>
  let { notifications = $bindable() } = $props();

  const dismissCard = (id) => {
    notifications = notifications.map(n => n.id === id ? { ...n, closing: true } : n);
    setTimeout(() => {
      notifications = notifications.filter(n => n.id !== id);
    }, 300); // matches closing animation duration
  };

  const getIconAnimationClass = (animation) => {
    if (!animation) return '';
    switch(animation) {
      case 'spin': return 'fa-spin';
      case 'spinPulse': return 'fa-spin fa-pulse';
      case 'spinReverse': return 'fa-spin fa-spin-reverse';
      case 'pulse': return 'fa-pulse';
      case 'beat': return 'fa-beat';
      case 'fade': return 'fa-fade';
      case 'beatFade': return 'fa-beat fa-fade';
      case 'bounce': return 'fa-bounce';
      case 'shake': return 'fa-shake';
      default: return '';
    }
  };

  const getDefaultNotifyIcon = (type) => {
    switch(type) {
      case 'success': return 'fas fa-circle-check';
      case 'warning': return 'fas fa-triangle-exclamation';
      case 'error': return 'fas fa-circle-xmark';
      case 'info':
      default: return 'fas fa-circle-info';
    }
  };

  const positions = [
    'top', 'top-right', 'top-left',
    'bottom', 'bottom-right', 'bottom-left',
    'center-right', 'center-left'
  ];
</script>

<div id="notifications-wrapper">
  {#each positions as pos}
    <div id="notify-{pos}" class="notify-group">
      {#each notifications.filter(n => (n.position || 'top-right') === pos) as n (n.id)}
        <!-- svelte-ignore a11y_click_events_have_key_events -->
        <!-- svelte-ignore a11y_no_static_element_interactions -->
        <div 
          class="notify-card notify-{n.type || 'info'} {n.closing ? 'closing' : ''} pointer-all"
          style={n.style ? Object.entries(n.style).map(([k, v]) => `${k}:${v}`).join(';') : ''}
          onclick={() => dismissCard(n.id)}
          use:setupProgressTimer={{ id: n.id, duration: n.duration || 3000 }}
        >
          <div class="notify-icon {getIconAnimationClass(n.iconAnimation)}">
            {#if n.icon}
              {#if typeof n.icon === 'string'}
                <i class={n.icon.startsWith('fa-') || n.icon.includes(' ') ? (n.icon.includes(' ') ? n.icon : `fas ${n.icon}`) : `fas fa-${n.icon}`} style={n.iconColor ? `color:${n.iconColor}` : ''}></i>
              {:else if Array.isArray(n.icon)}
                <i class="{n.icon[0] || 'fas'} {n.icon[1] ? (n.icon[1].startsWith('fa-') ? n.icon[1] : `fa-${n.icon[1]}`) : ''}" style={n.iconColor ? `color:${n.iconColor}` : ''}></i>
              {/if}
            {:else}
              <i class={getDefaultNotifyIcon(n.type)}></i>
            {/if}
          </div>
          <div class="notify-body">
            {#if n.title}
              <div class="notify-title">{n.title}</div>
            {/if}
            {#if n.description}
              <div class="notify-desc">{n.description}</div>
            {/if}
          </div>
          {#if n.showDuration !== false}
            <div class="notify-progress-wrapper">
              <div class="notify-progress" style="animation: scaleXProgress {n.duration || 3000}ms linear forwards;"></div>
            </div>
          {/if}
        </div>
      {/each}
    </div>
  {/each}
</div>

<script module>
  export function setupProgressTimer(node, { id, duration }) {
    const timer = setTimeout(() => {
      node.click();
    }, duration);
    return {
      destroy() {
        clearTimeout(timer);
      }
    };
  }
</script>

<style>
  .notify-progress-wrapper {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 3px;
    background: rgba(255, 255, 255, 0.1);
    overflow: hidden;
  }
  .notify-progress {
    height: 100%;
    background: currentColor;
    transform-origin: left;
  }

  @keyframes scaleXProgress {
    from {
      transform: scaleX(1);
    }
    to {
      transform: scaleX(0);
    }
  }
</style>
