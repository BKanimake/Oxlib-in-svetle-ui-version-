<script>
  import { onMount } from 'svelte';

  let { inputConfig, post, onclose } = $props();

  // State to hold the current input values for each row
  let formValues = $state([]);

  $effect(() => {
    if (inputConfig) {
      // Initialize formValues based on row defaults
      formValues = (inputConfig.rows || []).map(row => {
        if (row.type === 'checkbox') {
          return !!row.checked;
        }
        if (row.type === 'multi-select') {
          return row.default ? [...row.default] : [];
        }
        if (row.type === 'date-range') {
          const d1 = row.default && row.default[0] ? row.default[0] : '';
          const d2 = row.default && row.default[1] ? row.default[1] : '';
          return [d1, d2];
        }
        if (row.type === 'slider') {
          return row.default !== undefined ? row.default : (row.min || 0);
        }
        if (row.type === 'number') {
          return row.default !== undefined ? Number(row.default) : null;
        }
        return row.default !== undefined ? row.default : '';
      });
    }
  });

  const handleCancel = () => {
    post('inputData', null);
    onclose();
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    post('inputData', formValues);
    onclose();
  };

  const handleMultiSelectChange = (index, value, checked, max) => {
    let currentSelected = [...formValues[index]];
    if (checked) {
      if (max && currentSelected.length >= max) {
        // Prevent selection
        return;
      }
      currentSelected.push(value);
    } else {
      currentSelected = currentSelected.filter(v => v !== value);
    }
    formValues[index] = currentSelected;
  };

  // Helper for rendering icons
  const getIconClass = (icon) => {
    if (!icon) return '';
    if (typeof icon === 'string') {
      return icon.startsWith('fa-') || icon.includes(' ') ? (icon.includes(' ') ? icon : `fas ${icon}`) : `fas fa-${icon}`;
    } else if (Array.isArray(icon)) {
      const style = icon[0] || 'fas';
      const name = icon[1] ? (icon[1].startsWith('fa-') ? icon[1] : `fa-${icon[1]}`) : '';
      return `${style} ${name}`;
    }
    return '';
  };
</script>

<!-- svelte-ignore a11y_click_events_have_key_events -->
<!-- svelte-ignore a11y_no_static_element_interactions -->
<div id="input-container" class="overlay-container active" onclick={handleCancel}>
  <!-- svelte-ignore a11y_no_noninteractive_element_interactions -->
  <form id="input-form" class="modal-card active" onclick={(e) => e.stopPropagation()} onsubmit={handleSubmit}>
    <div id="input-header">{inputConfig.heading || 'Input'}</div>
    
    <div id="input-rows" class="scroll-y">
      {#each inputConfig.rows || [] as row, index}
        <div class="input-row">
          <!-- Label and required star -->
          {#if row.label && row.type !== 'checkbox'}
            <div class="input-label-container">
              {#if row.icon}
                <span class="input-row-icon">
                  <i class={getIconClass(row.icon)} style={row.iconColor ? `color:${row.iconColor}` : ''}></i>
                </span>
              {/if}
              <span class="input-label">{row.label}</span>
              {#if row.required}
                <span class="input-req">*</span>
              {/if}
            </div>
          {/if}

          <!-- Input element depending on type -->
          {#if row.type === 'textarea'}
            <textarea 
              class="textarea-input" 
              bind:value={formValues[index]} 
              required={row.required} 
              disabled={row.disabled} 
              placeholder={row.placeholder || ''}
            ></textarea>

          {:else if row.type === 'checkbox'}
            <!-- svelte-ignore a11y_label_has_associated_control -->
            <label class="checkbox-label">
              <input 
                type="checkbox" 
                class="checkbox-input" 
                bind:checked={formValues[index]} 
                disabled={row.disabled}
              />
              {#if row.icon}
                <i class={getIconClass(row.icon)} style={row.iconColor ? `color:${row.iconColor}` : ''}></i>
              {/if}
              <span>{row.label || ''}</span>
            </label>

          {:else if row.type === 'select'}
            <select 
              class="select-input" 
              bind:value={formValues[index]} 
              required={row.required} 
              disabled={row.disabled}
            >
              {#each row.options || [] as opt}
                <option value={opt.value}>{opt.label || opt.value}</option>
              {/each}
            </select>

          {:else if row.type === 'multi-select'}
            <div class="multiselect-container" data-max={row.maxSelectedValues || 999}>
              {#each row.options || [] as opt}
                {@const isChecked = formValues[index]?.includes(opt.value)}
                {@const isAtMax = row.maxSelectedValues && formValues[index]?.length >= row.maxSelectedValues}
                <label class="multiselect-option">
                  <input 
                    type="checkbox" 
                    class="checkbox-input" 
                    checked={isChecked}
                    disabled={row.disabled || (isAtMax && !isChecked)}
                    onchange={(e) => handleMultiSelectChange(index, opt.value, e.target.checked, row.maxSelectedValues)}
                  />
                  <span>{opt.label || opt.value}</span>
                </label>
              {/each}
            </div>

          {:else if row.type === 'slider'}
            <div class="slider-container">
              <input 
                type="range" 
                class="range-input" 
                min={row.min || 0} 
                max={row.max || 100} 
                step={row.step || 1} 
                bind:value={formValues[index]} 
                disabled={row.disabled}
              />
              <span class="slider-val">{formValues[index]}</span>
            </div>

          {:else if row.type === 'number'}
            <input 
              type="number" 
              class="text-input" 
              min={row.min} 
              max={row.max} 
              step={row.step} 
              bind:value={formValues[index]} 
              required={row.required} 
              disabled={row.disabled} 
              placeholder={row.placeholder || ''}
            />

          {:else if row.type === 'date'}
            <input 
              type="date" 
              class="text-input" 
              bind:value={formValues[index]} 
              required={row.required} 
              disabled={row.disabled}
            />

          {:else if row.type === 'date-range'}
            <div class="datetime-container">
              <input 
                type="date" 
                class="text-input" 
                bind:value={formValues[index][0]} 
                required={row.required} 
                disabled={row.disabled}
              />
              <input 
                type="date" 
                class="text-input" 
                bind:value={formValues[index][1]} 
                required={row.required} 
                disabled={row.disabled}
              />
            </div>

          {:else if row.type === 'time'}
            <input 
              type="time" 
              class="text-input" 
              bind:value={formValues[index]} 
              required={row.required} 
              disabled={row.disabled}
            />

          {:else if row.type === 'color'}
            <input 
              type="color" 
              class="text-input" 
              bind:value={formValues[index]} 
              disabled={row.disabled}
            />

          {:else if row.type === 'password'}
            <input 
              type="password" 
              class="text-input" 
              bind:value={formValues[index]} 
              required={row.required} 
              disabled={row.disabled} 
              placeholder={row.placeholder || ''}
            />

          {:else}
            <!-- Default Input Text -->
            <input 
              type="text" 
              class="text-input" 
              bind:value={formValues[index]} 
              required={row.required} 
              disabled={row.disabled} 
              placeholder={row.placeholder || ''}
            />
          {/if}

          {#if row.description}
            <div class="input-desc">{row.description}</div>
          {/if}
        </div>
      {/each}
    </div>

    <div id="input-footer" class="modal-footer">
      <button type="button" id="input-btn-cancel" class="btn btn-secondary pointer-all" onclick={handleCancel}>Cancel</button>
      <button type="submit" id="input-btn-submit" class="btn btn-primary pointer-all">Submit</button>
    </div>
  </form>
</div>
