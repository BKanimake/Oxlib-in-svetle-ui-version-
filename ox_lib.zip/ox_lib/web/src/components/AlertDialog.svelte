<script>
  let { alertConfig, post, onclose } = $props();

  const handleAction = (action) => {
    post('closeAlert', action);
    onclose();
  };
</script>

<!-- svelte-ignore a11y_click_events_have_key_events -->
<!-- svelte-ignore a11y_no_static_element_interactions -->
<div id="alert-container" class="overlay-container active" onclick={() => handleAction('cancel')}>
  <div id="alert-box" class="modal-card active size-{alertConfig.size || 'sm'}" onclick={(e) => e.stopPropagation()}>
    <div id="alert-header">{alertConfig.header || 'Alert'}</div>
    <div id="alert-content" style="text-align: {alertConfig.centered ? 'center' : 'left'}">
      <!-- eslint-disable-next-line svelte/no-at-html-tags -->
      {@html alertConfig.content || ''}
    </div>
    <div id="alert-footer" class="modal-footer">
      {#if alertConfig.cancel !== false}
        <button id="alert-btn-cancel" class="btn btn-secondary pointer-all" onclick={() => handleAction('cancel')}>
          {(alertConfig.labels && alertConfig.labels.cancel) || 'Cancel'}
        </button>
      {/if}
      <button id="alert-btn-confirm" class="btn btn-primary pointer-all" onclick={() => handleAction('confirm')}>
        {(alertConfig.labels && alertConfig.labels.confirm) || 'Confirm'}
      </button>
    </div>
  </div>
</div>
