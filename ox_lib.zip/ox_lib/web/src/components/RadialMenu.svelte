<script>
  import { onMount } from 'svelte';

  let { radialMenuConfig, post, onclose } = $props();

  let activeTooltipLabel = $state('');
  let isTooltipActive = $state(false);

  // Sector Math Helper
  const getSectorPath = (cx, cy, rIn, rOut, startAngle, endAngle) => {
    const toRad = a => (a - 90) * Math.PI / 180;
    const x1In = cx + rIn * Math.cos(toRad(startAngle));
    const y1In = cy + rIn * Math.sin(toRad(startAngle));
    const x1Out = cx + rOut * Math.cos(toRad(startAngle));
    const y1Out = cy + rOut * Math.sin(toRad(startAngle));
    const x2In = cx + rIn * Math.cos(toRad(endAngle));
    const y2In = cy + rIn * Math.sin(toRad(endAngle));
    const x2Out = cx + rOut * Math.cos(toRad(endAngle));
    const y2Out = cy + rOut * Math.sin(toRad(endAngle));
    
    const largeArc = (endAngle - startAngle) > 180 ? 1 : 0;
    
    return `
      M ${x1Out} ${y1Out}
      A ${rOut} ${rOut} 0 ${largeArc} 1 ${x2Out} ${y2Out}
      L ${x2In} ${y2In}
      A ${rIn} ${rIn} 0 ${largeArc} 0 ${x1In} ${y1In}
      Z
    `;
  };

  onMount(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' || e.key === 'Backspace') {
        e.preventDefault();
        handleClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  });

  const handleClose = () => {
    post('radialClose');
    onclose();
  };

  const handleCenterClick = () => {
    if (radialMenuConfig.sub) {
      post('radialBack');
    } else {
      handleClose();
    }
  };

  const handleItemClick = (index) => {
    post('radialClick', index);
  };

  const handleMouseEnter = (label) => {
    activeTooltipLabel = label;
    isTooltipActive = true;
  };

  const handleMouseLeave = () => {
    isTooltipActive = false;
  };

  // Helper for rendering icons
  const getIconClass = (icon) => {
    if (!icon) return '';
    if (typeof icon === 'string') {
      return icon.startsWith('fa-') || icon.includes(' ') ? (icon.includes(' ') ? icon : `fas ${icon}`) : `fas fa-${icon}`;
    } else if (Array.isArray(icon)) {
      const style = icon[0] || 'fas';
      const name = icon[1] ? (icon[1].startsWith('fa-') ? icon[1] : `fa-${icon[1]}`) : '';
      return `${style} ${name}`;
    }
    return '';
  };

  // Computed layout variables
  const cx = 200;
  const cy = 200;
  const rIn = 70;
  const rOut = 180;
  
  const items = $derived(radialMenuConfig.items || []);
  const count = $derived(items.length);
  const angleStep = $derived(360 / count);
  const gap = $derived(count > 1 ? 2 : 0);

  // Computes the sector coordinates for each item
  const slices = $derived(
    items.map((item, index) => {
      const startAngle = index * angleStep + gap / 2;
      const endAngle = (index + 1) * angleStep - gap / 2;
      const middleAngle = startAngle + (endAngle - startAngle) / 2;
      const toRad = a => (a - 90) * Math.PI / 180;
      const midR = (rIn + rOut) / 2;
      
      const iconX = cx + midR * Math.cos(toRad(middleAngle));
      const iconY = cy + midR * Math.sin(toRad(middleAngle));

      return {
        pathData: getSectorPath(cx, cy, rIn, rOut, startAngle, endAngle),
        iconX: iconX - 16,
        iconY: iconY - 24,
        textX: iconX,
        textY: iconY + 22,
        item,
        index
      };
    })
  );
</script>

<!-- svelte-ignore a11y_click_events_have_key_events -->
<!-- svelte-ignore a11y_no_static_element_interactions -->
<div id="radial-container" class="overlay-container active" onclick={handleClose}>
  <div id="radial-menu-wrapper" onclick={(e) => e.stopPropagation()}>
    <svg id="radial-svg" viewBox="0 0 400 400">
      {#each slices as slice}
        <!-- Sector Slice Path -->
        <path 
          d={slice.pathData} 
          class="radial-sector" 
          onmouseenter={() => handleMouseEnter(slice.item.label)}
          onmouseleave={handleMouseLeave}
          onclick={() => handleItemClick(slice.index)}
        ></path>

        <!-- Icon & Text Group -->
        <g class="radial-item-group" style="pointer-events: none;">
          <!-- SVG Foreign Object to embed HTML FontAwesome icon -->
          <foreignObject x={slice.iconX} y={slice.iconY} width="32" height="32">
            <div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;color:#fff;font-size:20px;">
              <i class={getIconClass(slice.item.icon)}></i>
            </div>
          </foreignObject>

          <!-- Label -->
          <text x={slice.textX} y={slice.textY} class="radial-label">
            {slice.item.label}
          </text>
        </g>
      {/each}
    </svg>

    <!-- Center Button -->
    <div id="radial-center-btn" onclick={handleCenterClick}>
      {#if radialMenuConfig.sub}
        <i id="radial-center-icon" class="fas fa-chevron-left"></i>
      {:else}
        <i id="radial-center-icon" class="fas fa-xmark"></i>
      {/if}
    </div>

    <!-- Tooltip -->
    <div id="radial-tooltip" class={isTooltipActive ? 'active' : ''}>
      <div id="radial-tooltip-label">{activeTooltipLabel}</div>
    </div>
  </div>
</div>
