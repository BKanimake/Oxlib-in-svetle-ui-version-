<script>
  import { onMount, onDestroy } from 'svelte';

  let { tabletConfig = $bindable(), post, onclose } = $props();

  let tabletTime = $state('10:24 AM');
  let timeTimer;
  
  // Alert modal inside tablet (for Citizen Database profile view)
  let localAlert = $state(null);

  // Simulated bio-scanner state inside tablet
  let fingerScannerState = $state('idle'); // 'idle' | 'scanning' | 'matched'
  let fingerScannerText = $state('');
  let fingerMatchedPlayer = $state(null);

  // Medical app logs state
  let medicalLogs = $state([
    { time: '10:20:12 AM', message: 'Bio-system initialized successfully.' },
    { time: '10:22:45 AM', message: 'Diagnostics check: 0 anomalies found.' }
  ]);

  // Mock citizen database
  const mockPlayers = [
    { name: 'John Doe', dob: '12/05/1995', job: 'Unemployed', status: 'Active' },
    { name: 'Sarah Smith', dob: '04/18/1998', job: 'Doctor', status: 'Active' },
    { name: 'Michael Caine', dob: '09/22/1990', job: 'Police Officer', status: 'Active' },
    { name: 'David Jones', dob: '01/30/2001', job: 'Mechanic', status: 'Active' }
  ];

  // Default Apps
  const defaultApps = [
    { id: 'settings', label: 'Settings', icon: 'fas fa-sliders', color: '#3b82f6' },
    { id: 'players', label: 'Database', icon: 'fas fa-users', color: '#10b981' },
    { id: 'fingerprint', label: 'Scanner', icon: 'fas fa-fingerprint', color: '#8b5cf6' },
    { id: 'medical', label: 'Medical', icon: 'fas fa-heart-pulse', color: '#ef4444' }
  ];

  const updateTabletTime = () => {
    const date = new Date();
    let hours = date.getHours();
    let minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    minutes = minutes < 10 ? '0' + minutes : minutes;
    tabletTime = hours + ':' + minutes + ' ' + ampm;
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      if (localAlert) {
        localAlert = null;
      } else {
        handleCloseTablet();
      }
    }
  };

  onMount(() => {
    updateTabletTime();
    timeTimer = setInterval(updateTabletTime, 30000);
    window.addEventListener('keydown', handleKeyDown);
  });

  onDestroy(() => {
    clearInterval(timeTimer);
    window.removeEventListener('keydown', handleKeyDown);
  });

  const handleCloseTablet = (notifyServer = true) => {
    if (notifyServer) {
      post('tabletClose', { tabletId: tabletConfig.tabletId });
    }
    onclose();
  };

  const handleHomeBtn = () => {
    if (tabletConfig.currentView === 'home') {
      handleCloseTablet();
    } else {
      tabletConfig.currentView = 'home';
      tabletConfig.activeAppId = null;
    }
  };

  const handleAppSelect = (appId) => {
    const isDefault = defaultApps.some(a => a.id === appId);
    if (isDefault) {
      tabletConfig.activeAppId = appId;
      tabletConfig.currentView = 'app';
    } else {
      post('tabletAppSelect', { tabletId: tabletConfig.tabletId, appId: appId });
    }
  };

  // Settings App theme action
  const handleThemeChange = (color, shade) => {
    document.documentElement.style.setProperty('--primary-color', color);
    post('tabletAction', { app: 'settings', action: 'themeChange', color: color, shade: shade });
  };

  // Database app citizen profile view
  const viewCitizenProfile = (player) => {
    localAlert = {
      header: 'Citizen Profile: ' + player.name,
      content: `
        <p><strong>Full Name:</strong> ${player.name}</p>
        <p><strong>Date of Birth:</strong> ${player.dob}</p>
        <p><strong>Occupation:</strong> ${player.job}</p>
        <p><strong>Records Status:</strong> ${player.status}</p>
      `
    };
  };

  // Fingerprint Scanner Scan Action
  const startFingerprintScan = () => {
    if (fingerScannerState === 'scanning') return;
    
    fingerScannerState = 'scanning';
    fingerScannerText = 'Initializing bio-scanner...';
    fingerMatchedPlayer = null;

    setTimeout(() => {
      fingerScannerText = 'Reading fingerprint ridge patterns...';
    }, 800);

    setTimeout(() => {
      fingerScannerState = 'matched';
      const p = mockPlayers[Math.floor(Math.random() * mockPlayers.length)];
      fingerMatchedPlayer = p;
      fingerScannerText = '';

      post('tabletAction', { app: 'fingerprint', action: 'matchFound', citizen: p.name });
    }, 2500);
  };

  // Medical App blood actions
  const addMedicalLog = (message) => {
    const time = tabletTime.split(' ')[0] + ' ' + tabletTime.split(' ')[1];
    medicalLogs = [{ time, message }, ...medicalLogs];
  };

  const handleMedicalAction = (action) => {
    if (action === 'extract') {
      addMedicalLog('Initiating Bloodbag Extraction process...');
      handleCloseTablet(false);
      post('tabletAction', { app: 'medical', action: 'extractBlood' });
    } else if (action === 'transfuse') {
      addMedicalLog('Initiating Bloodbag Transfusion process...');
      handleCloseTablet(false);
      post('tabletAction', { app: 'medical', action: 'transfuseBlood' });
    }
  };

  // Custom action binder directive for custom HTML app injection
  const customActionBinder = (node, { appId }) => {
    const setupListeners = () => {
      const actionElements = node.querySelectorAll('[data-action]');
      actionElements.forEach(el => {
        el.onclick = (e) => {
          e.preventDefault();
          const action = el.getAttribute('data-action');
          
          // Collect payload
          const payload = {};
          for (let i = 0; i < el.attributes.length; i++) {
            const attr = el.attributes[i];
            if (attr.name.startsWith('data-') && attr.name !== 'data-action') {
              const key = attr.name.slice(5).replace(/-([a-z])/g, g => g[1].toUpperCase());
              payload[key] = attr.value;
            }
          }
          
          post('tabletAppEvent', { 
            tabletId: tabletConfig.tabletId, 
            appId: appId, 
            action: action, 
            payload: payload 
          });
        };
      });
    };

    setupListeners();

    // Re-bind if DOM mutations occur inside custom HTML app
    const observer = new MutationObserver(setupListeners);
    observer.observe(node, { childList: true, subtree: true });

    return {
      destroy() {
        observer.disconnect();
      }
    };
  };

  // Get active app details
  const activeApp = $derived(
    (tabletConfig.apps || defaultApps).find(a => a.id === tabletConfig.activeAppId)
  );
</script>

<!-- svelte-ignore a11y_click_events_have_key_events -->
<!-- svelte-ignore a11y_no_static_element_interactions -->
<div id="tablet-container" class="overlay-container active pointer-none">
  <div id="tablet-frame" class="pointer-all" onclick={(e) => e.stopPropagation()}>
    <!-- Bezel camera dot -->
    <div id="tablet-camera-dot"></div>

    <div id="tablet-screen">
      <!-- Status Bar -->
      <div id="tablet-status-bar">
        <div class="status-left">
          <span id="tablet-wifi-icon"><i class="fas fa-wifi"></i></span>
          <span id="tablet-network">LTE</span>
        </div>
        <div class="status-center">
          <span id="tablet-time">{tabletTime}</span>
        </div>
        <div class="status-right">
          <span id="tablet-battery-percent">98%</span>
          <span id="tablet-battery-icon"><i class="fas fa-battery-three-quarters"></i></span>
        </div>
      </div>

      {#if tabletConfig.currentView === 'home'}
        <!-- Home Screen -->
        <div id="tablet-home-screen" class="tablet-view active">
          <div class="home-logo-area">
            <div id="tablet-home-title" class="home-title">{tabletConfig.title}</div>
            <div id="tablet-home-subtitle" class="home-subtitle">{tabletConfig.subtitle}</div>
          </div>
          
          <div id="tablet-apps-grid">
            {#each (tabletConfig.apps || defaultApps) as app}
              <div 
                class="app-card pointer-all" 
                style="--app-color: {app.color || '#3b82f6'};"
                onclick={() => handleAppSelect(app.id)}
              >
                <div class="app-icon"><i class={app.icon || 'fas fa-cubes'}></i></div>
                <div class="app-label">{app.label}</div>
              </div>
            {/each}
            
            <!-- Power Shut Down app -->
            <div 
              class="app-card pointer-all" 
              style="--app-color: #6b7280;"
              onclick={() => handleCloseTablet()}
            >
              <div class="app-icon"><i class="fas fa-power-off"></i></div>
              <div class="app-label">Shut Down</div>
            </div>
          </div>
        </div>
      {:else if tabletConfig.currentView === 'app'}
        <!-- App Window view -->
        <div id="tablet-app-window" class="tablet-view active">
          <div id="tablet-app-header">
            <div id="tablet-app-back-btn" class="pointer-all" onclick={() => { tabletConfig.currentView = 'home'; tabletConfig.activeAppId = null; }}>
              <i class="fas fa-arrow-left"></i> Home
            </div>
            <div id="tablet-app-title">
              {tabletConfig.customContent[tabletConfig.activeAppId] ? tabletConfig.customContent[tabletConfig.activeAppId].title : (activeApp ? activeApp.label : 'Application')}
            </div>
            <div style="width: 70px;"></div> <!-- Spacer -->
          </div>

          <div id="tablet-app-body" class="scroll-y">
            <!-- Render custom HTML app via post payload if injected -->
            {#if tabletConfig.customContent[tabletConfig.activeAppId]}
              <div 
                use:customActionBinder={{ appId: tabletConfig.activeAppId }}
                style="height: 100%;"
              >
                <!-- eslint-disable-next-line svelte/no-at-html-tags -->
                {@html tabletConfig.customContent[tabletConfig.activeAppId].html}
              </div>
            {:else}
              <!-- Default Native Apps -->
              {#if tabletConfig.activeAppId === 'settings'}
                <!-- Settings App -->
                <div class="settings-group">
                  <div class="settings-title">Primary Color Theme</div>
                  <div class="swatch-grid">
                    <div class="color-swatch pointer-all" style="background-color: #3b82f6;" onclick={() => handleThemeChange('#3b82f6', 'blue')}>Blue</div>
                    <div class="color-swatch pointer-all" style="background-color: #10b981;" onclick={() => handleThemeChange('#10b981', 'green')}>Green</div>
                    <div class="color-swatch pointer-all" style="background-color: #ef4444;" onclick={() => handleThemeChange('#ef4444', 'red')}>Red</div>
                    <div class="color-swatch pointer-all" style="background-color: #eab308;" onclick={() => handleThemeChange('#eab308', 'yellow')}>Yellow</div>
                    <div class="color-swatch pointer-all" style="background-color: #8b5cf6;" onclick={() => handleThemeChange('#8b5cf6', 'violet')}>Purple</div>
                    <div class="color-swatch pointer-all" style="background-color: #ec4899;" onclick={() => handleThemeChange('#ec4899', 'pink')}>Pink</div>
                  </div>
                </div>
                <div class="settings-group">
                  <div class="settings-title">System Status</div>
                  <div style="font-size:0.85rem;color:var(--text-muted);line-height:1.6;">
                    <p>Device OS: OS X-TABLET v3.3.0</p>
                    <p>UI Render Core: Svelte 5 / Vite Bundle</p>
                    <p>CSS Engine: Vanilla Flexbox & Grid</p>
                  </div>
                </div>

              {:else if tabletConfig.activeAppId === 'players'}
                <!-- Citizen Database App -->
                <div class="player-list">
                  {#each mockPlayers as p}
                    <div class="player-item">
                      <div class="player-meta">
                        <div class="player-badge"><i class="fas fa-user"></i></div>
                        <div class="player-name-job">
                          <span class="player-n">{p.name}</span>
                          <span class="player-j">DOB: {p.dob} | Job: {p.job}</span>
                        </div>
                      </div>
                      <button class="player-btn-view pointer-all" onclick={() => viewCitizenProfile(p)}>View Info</button>
                    </div>
                  {/each}
                </div>

              {:else if tabletConfig.activeAppId === 'fingerprint'}
                <!-- Fingerprint Scanner App -->
                <div class="fingerprint-screen">
                  <!-- svelte-ignore a11y_click_events_have_key_events -->
                  <div 
                    id="tablet-finger-scanner" 
                    class="scanner-area {fingerScannerState === 'scanning' ? 'scanning' : ''} pointer-all"
                    onclick={startFingerprintScan}
                  >
                    <div class="scanner-laser"></div>
                    <div class="scanner-icon"><i class="fas fa-fingerprint"></i></div>
                  </div>
                  <button 
                    id="tablet-finger-scan-btn" 
                    class="scanner-btn pointer-all"
                    onclick={startFingerprintScan}
                  >
                    Begin Fingerprint Scan
                  </button>
                  
                  <div id="tablet-finger-results" style="margin-top:25px;width:100%;text-align:center;">
                    {#if fingerScannerState === 'scanning'}
                      <span style="color:var(--text-muted);font-weight:700;">{fingerScannerText}</span>
                    {:else if fingerScannerState === 'matched' && fingerMatchedPlayer}
                      <div style="background:rgba(16,185,129,0.06);border:1px solid rgba(16,185,129,0.3);border-radius:10px;padding:15px;display:inline-block;text-align:left;line-height:1.6;">
                        <div style="font-weight:800;color:var(--success-color);margin-bottom:6px;text-align:center;"><i class="fas fa-circle-check"></i> Match Found (100% Pattern Match)</div>
                        <p><strong>Citizen ID:</strong> C-{Math.floor(Math.random() * 89999 + 10000)}</p>
                        <p><strong>Matches Record:</strong> {fingerMatchedPlayer.name} (DOB: {fingerMatchedPlayer.dob})</p>
                        <p><strong>Employment File:</strong> {fingerMatchedPlayer.job}</p>
                      </div>
                    {/if}
                  </div>
                </div>

              {:else if tabletConfig.activeAppId === 'medical'}
                <!-- Medical App -->
                <div class="medical-grid">
                  <!-- svelte-ignore a11y_click_events_have_key_events -->
                  <div class="medical-card-btn pointer-all" onclick={() => handleMedicalAction('extract')}>
                    <div class="medical-btn-icon"><i class="fas fa-syringe"></i></div>
                    <div class="medical-btn-title">Blood Extraction</div>
                    <div class="medical-btn-desc">Initiates blood bag extraction from a patient. Plays animation and gives Full Blood Bag.</div>
                  </div>
                  <!-- svelte-ignore a11y_click_events_have_key_events -->
                  <div class="medical-card-btn pointer-all" onclick={() => handleMedicalAction('transfuse')}>
                    <div class="medical-btn-icon"><i class="fas fa-droplet"></i></div>
                    <div class="medical-btn-title">Blood Transfusion</div>
                    <div class="medical-btn-desc">Transfuses a full blood bag into a patient to restore health to maximum level.</div>
                  </div>
                </div>
                <div class="settings-group" style="margin-top:20px;">
                  <div class="settings-title">Emergency Logs</div>
                  <div id="medical-logs" style="font-size:0.75rem;color:var(--text-muted);display:flex;flex-direction:column;gap:6px;">
                    {#each medicalLogs as log}
                      <div>[{log.time}] - {log.message}</div>
                    {/each}
                  </div>
                </div>
              {/if}
            {/if}
          </div>
        </div>
      {/if}
    </div>

    <!-- Home Button on Bezel -->
    <!-- svelte-ignore a11y_click_events_have_key_events -->
    <div id="tablet-home-btn" class="pointer-all" onclick={handleHomeBtn}></div>
  </div>
</div>

<!-- Local Alert Modal (For DB profile details) -->
{#if localAlert}
  <!-- svelte-ignore a11y_click_events_have_key_events -->
  <!-- svelte-ignore a11y_no_static_element_interactions -->
  <div id="alert-container" class="overlay-container active" onclick={() => localAlert = null} style="z-index: 9999;">
    <div id="alert-box" class="modal-card active size-sm" onclick={(e) => e.stopPropagation()}>
      <div id="alert-header">{localAlert.header}</div>
      <div id="alert-content" style="text-align: left; line-height: 1.8;">
        <!-- eslint-disable-next-line svelte/no-at-html-tags -->
        {@html localAlert.content}
      </div>
      <div id="alert-footer" class="modal-footer">
        <button id="alert-btn-confirm" class="btn btn-primary pointer-all" onclick={() => localAlert = null}>
          Close Database Profile
        </button>
      </div>
    </div>
  </div>
{/if}
