<script>
  import { onMount, onDestroy } from 'svelte';

  let { progressConfig, post, onclose } = $props();

  let elapsed = $state(0);
  let progressPercent = $state(0);
  let secondsRemaining = $state('0.0');
  let animationId;
  let startTime;

  onMount(() => {
    startTime = performance.now();
    
    const tick = (now) => {
      const duration = progressConfig.duration || 1000;
      const timeDiff = now - startTime;
      const progress = Math.min(timeDiff / duration, 1);
      
      elapsed = timeDiff;
      progressPercent = Math.round(progress * 100);
      secondsRemaining = Math.max(0, (duration - timeDiff) / 1000).toFixed(1);

      if (progress < 1) {
        animationId = requestAnimationFrame(tick);
      } else {
        setTimeout(handleComplete, 200);
      }
    };

    animationId = requestAnimationFrame(tick);

    // Cancel key listener in case NUI gets keyboard focus
    const handleKeyDown = (e) => {
      if (progressConfig.canCancel && e.key.toLowerCase() === 'x') {
        e.preventDefault();
        handleCancel();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      if (animationId) cancelAnimationFrame(animationId);
      window.removeEventListener('keydown', handleKeyDown);
    };
  });

  const handleComplete = () => {
    post('progressComplete');
    onclose();
  };

  const handleCancel = () => {
    // If the user manually cancels progress
    post('progressCancel');
    onclose();
  };

  // Helper for rendering icons
  const getIconClass = (icon) => {
    if (!icon) return '';
    let iconClass = '';
    if (typeof icon === 'string') {
      iconClass = icon.startsWith('fa-') || icon.includes(' ') ? (icon.includes(' ') ? icon : `fas ${icon}`) : `fas fa-${icon}`;
    } else if (Array.isArray(icon)) {
      const style = icon[0] || 'fas';
      const name = icon[1] ? (icon[1].startsWith('fa-') ? icon[1] : `fa-${icon[1]}`) : '';
      iconClass = `${style} ${name}`;
    }
    
    // Add default spin/pulse if it's a gear/cog/spinner/sync/arrows
    const iconName = typeof icon === 'string' ? icon : (Array.isArray(icon) ? icon[1] : '');
    if (iconName && (iconName.includes('cog') || iconName.includes('gear') || iconName.includes('spinner') || iconName.includes('sync') || iconName.includes('circle-notch') || iconName.includes('wrench'))) {
      iconClass += ' fa-spin';
    }
    
    return iconClass;
  };

  // Circular progress SVG setup (r=45, circumference = 2 * PI * r = ~283)
  const totalDash = 283;
  let strokeDashoffset = $derived(totalDash - (Math.min(elapsed / (progressConfig.duration || 1000), 1) * totalDash));
</script>

<!-- svelte-ignore a11y_click_events_have_key_events -->
<!-- svelte-ignore a11y_no_static_element_interactions -->
<div id="progress-container" class="overlay-container active pointer-none">
  {#if progressConfig.type === 'linear'}
    <!-- Linear Progress Bar -->
    <div 
      id="progress-bar-box" 
      class="progress-box progress-{progressConfig.position || 'bottom'} pointer-all"
      style="display: flex;"
      onclick={() => progressConfig.canCancel && handleCancel()}
    >
      <div class="progress-bar-header">
        <div class="progress-bar-label-group">
          {#if progressConfig.icon}
            <span id="progress-bar-icon" style="display: inline-flex;">
              <i class={getIconClass(progressConfig.icon)} style={progressConfig.iconColor ? `color:${progressConfig.iconColor}` : ''}></i>
            </span>
          {/if}
          <span id="progress-bar-label">{progressConfig.label || 'Progress...'}</span>
        </div>
        <span id="progress-bar-time-percent">{progressPercent}% ({secondsRemaining}s)</span>
      </div>
      <div class="progress-bar-track">
        <div 
          id="progress-bar-fill" 
          style="
            width: {Math.min(elapsed / (progressConfig.duration || 1000), 1) * 100}%;
            background: {progressConfig.color || ''};
            box-shadow: {progressConfig.color ? `0 0 10px ${progressConfig.color}` : ''};
          "
        ></div>
      </div>
      {#if progressConfig.canCancel}
        <div id="progress-bar-cancel" class="progress-cancel-badge">
          <kbd>X</kbd> to cancel
        </div>
      {/if}
    </div>
  {:else if progressConfig.type === 'circle'}
    <!-- Circular Progress -->
    <div 
      id="progress-circle-box" 
      class="progress-box progress-{progressConfig.position || 'middle'} pointer-all"
      style="display: flex;"
      onclick={() => progressConfig.canCancel && handleCancel()}
    >
      <div class="circle-svg-wrapper">
        <svg class="progress-circle-svg" viewBox="0 0 100 100">
          <circle class="progress-ring-bg" cx="50" cy="50" r="45"></circle>
          <circle 
            id="progress-ring-fill" 
            class="progress-ring-fill" 
            cx="50" 
            cy="50" 
            r="45"
            style="
              stroke-dasharray: {totalDash};
              stroke-dashoffset: {strokeDashoffset};
              stroke: {progressConfig.color || ''};
              filter: {progressConfig.color ? `drop-shadow(0 0 4px ${progressConfig.color})` : ''};
            "
          ></circle>
        </svg>
        <div id="progress-circle-center">
          {#if progressConfig.icon}
            <span id="progress-circle-icon" style="display: inline-flex;">
              <i class={getIconClass(progressConfig.icon)} style={progressConfig.iconColor ? `color:${progressConfig.iconColor}` : ''}></i>
            </span>
          {/if}
          <span id="progress-circle-percent" style="font-size: {progressConfig.icon ? '0.72rem' : '0.85rem'}">{progressPercent}%</span>
          <span id="progress-circle-time" style="font-size: {progressConfig.icon ? '0.62rem' : '0.65rem'}">{secondsRemaining}s</span>
        </div>
      </div>
      <div id="progress-circle-label">{progressConfig.label || 'Progress...'}</div>
      {#if progressConfig.canCancel}
        <div id="progress-circle-cancel" class="progress-cancel-badge">
          <kbd>X</kbd> to cancel
        </div>
      {/if}
    </div>
  {/if}
</div>
