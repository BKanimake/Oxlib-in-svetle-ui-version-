<script>
  import { onMount, onDestroy } from 'svelte';

  let { skillCheckConfig, post, onclose } = $props();

  let activeChallenge = $state(null);
  let needleAngle = $state(0);
  let promptKey = $state('E');
  let targetPathD = $state('');

  let challengeQueue = [];
  let animationId;
  let keyListener;
  let startTime;

  // Arc path formula
  const getArcD = (cx, cy, r, startAngle, endAngle) => {
    const toRad = a => (a - 90) * Math.PI / 180;
    const x1 = cx + r * Math.cos(toRad(startAngle));
    const y1 = cy + r * Math.sin(toRad(startAngle));
    const x2 = cx + r * Math.cos(toRad(endAngle));
    const y2 = cy + r * Math.sin(toRad(endAngle));
    const largeArc = (endAngle - startAngle) > 180 ? 1 : 0;
    return `M ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2}`;
  };

  onMount(() => {
    // Parse difficulty and inputs
    const diffs = Array.isArray(skillCheckConfig.difficulty) ? skillCheckConfig.difficulty : [skillCheckConfig.difficulty];
    const keys = skillCheckConfig.inputs || ['e'];

    challengeQueue = diffs.map((diff, idx) => {
      let size = 30;
      let speed = 1.2;
      
      if (typeof diff === 'string') {
        if (diff === 'easy') { size = 45; speed = 1.0; }
        else if (diff === 'medium') { size = 30; speed = 1.5; }
        else if (diff === 'hard') { size = 15; speed = 2.0; }
      } else if (typeof diff === 'object') {
        size = diff.areaSize || 30;
        speed = diff.speedMultiplier || 1.2;
      }

      // Random target angle
      const startAngle = Math.random() * 240 + 40;
      const endAngle = startAngle + size;

      return {
        startAngle,
        endAngle,
        speed,
        key: (keys[idx] || keys[0] || 'e').toLowerCase()
      };
    });

    // Start first round
    startNextChallenge();

    return () => {
      cleanupChallenge();
    };
  });

  const startNextChallenge = () => {
    if (challengeQueue.length === 0) {
      handleGameOver(true);
      return;
    }

    activeChallenge = challengeQueue.shift();
    needleAngle = 0;
    promptKey = activeChallenge.key.toUpperCase();
    targetPathD = getArcD(100, 100, 80, activeChallenge.startAngle, activeChallenge.endAngle);

    startTime = performance.now();
    const duration = 2000 / activeChallenge.speed;

    // Listen for keydown
    if (keyListener) window.removeEventListener('keydown', keyListener);
    keyListener = (e) => {
      if (e.key.toLowerCase() === activeChallenge.key) {
        e.preventDefault();
        
        // Success check
        const success = needleAngle >= activeChallenge.startAngle && needleAngle <= activeChallenge.endAngle;
        cleanupChallenge();

        if (success) {
          setTimeout(startNextChallenge, 150);
        } else {
          handleGameOver(false);
        }
      }
    };
    window.addEventListener('keydown', keyListener);

    // Animation Tick
    const tick = (now) => {
      const elapsed = now - startTime;
      needleAngle = (elapsed / duration) * 360;

      if (needleAngle >= 360) {
        // Time ran out!
        cleanupChallenge();
        handleGameOver(false);
      } else {
        animationId = requestAnimationFrame(tick);
      }
    };

    if (animationId) cancelAnimationFrame(animationId);
    animationId = requestAnimationFrame(tick);
  };

  const cleanupChallenge = () => {
    if (animationId) cancelAnimationFrame(animationId);
    if (keyListener) window.removeEventListener('keydown', keyListener);
    animationId = null;
    keyListener = null;
  };

  const handleGameOver = (success) => {
    post('skillCheckOver', success);
    onclose();
  };
</script>

<div id="skillcheck-container" class="overlay-container active">
  <div id="skillcheck-wrapper">
    <svg id="skillcheck-svg" viewBox="0 0 200 200">
      <circle class="skillcheck-bg" cx="100" cy="100" r="80"></circle>
      <path id="skillcheck-target" class="skillcheck-target" d={targetPathD}></path>
      <line 
        id="skillcheck-needle" 
        class="skillcheck-needle" 
        x1="100" 
        y1="100" 
        x2="100" 
        y2="20"
        transform="rotate({needleAngle} 100 100)"
      ></line>
    </svg>
    <div id="skillcheck-center">
      <span id="skillcheck-key">{promptKey}</span>
    </div>
  </div>
</div>
