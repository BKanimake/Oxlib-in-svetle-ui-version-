<script>
  let { textUIs } = $props();

  const getIconClass = (icon) => {
    if (!icon) return '';
    if (typeof icon === 'string') {
      return icon.startsWith('fa-') || icon.includes(' ') ? (icon.includes(' ') ? icon : `fas ${icon}`) : `fas fa-${icon}`;
    } else if (Array.isArray(icon)) {
      const style = icon[0] || 'fas';
      const name = icon[1] ? (icon[1].startsWith('fa-') ? icon[1] : `fa-${icon[1]}`) : '';
      return `${style} ${name}`;
    }
    return '';
  };

  const positions = ['right-center', 'left-center', 'top-center', 'bottom-center'];
</script>

<div id="textui-container" class="pointer-none">
  {#each positions as pos}
    {@const item = textUIs[pos]}
    {#if item}
      <div id="textui-{pos}" class="textui-group">
        <div 
          class="textui-pill"
          style={item.style ? (typeof item.style === 'string' ? item.style : Object.entries(item.style).map(([k, v]) => `${k}:${v}`).join(';')) : ''}
        >
          {#if item.icon}
            <div class="textui-icon">
              <i class={getIconClass(item.icon)} style={item.iconColor ? `color:${item.iconColor}` : ''}></i>
            </div>
          {/if}
          <!-- eslint-disable-next-line svelte/no-at-html-tags -->
          <div class="textui-content">{@html item.text || ''}</div>
        </div>
      </div>
    {:else}
      <div id="textui-{pos}" class="textui-group"></div>
    {/if}
  {/each}
</div>
