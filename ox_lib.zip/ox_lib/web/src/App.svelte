<script>
  import { onMount } from 'svelte';
  import Notifications from './components/Notifications.svelte';
  import AlertDialog from './components/AlertDialog.svelte';
  import ContextMenu from './components/ContextMenu.svelte';
  import InputDialog from './components/InputDialog.svelte';
  import KeyboardMenu from './components/KeyboardMenu.svelte';
  import Progress from './components/Progress.svelte';
  import RadialMenu from './components/RadialMenu.svelte';
  import SkillCheck from './components/SkillCheck.svelte';
  import Tablet from './components/Tablet.svelte';
  import TextUI from './components/TextUI.svelte';

  // --- Post Helper ---
  const post = (endpoint, data = {}) => {
    const resourceName = window.GetParentResourceName ? window.GetParentResourceName() : 'ox_lib';
    return fetch(`https://${resourceName}/${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=UTF-8' },
      body: JSON.stringify(data)
    }).catch(err => console.error('Failed to post to NUI: ', err));
  };

  // --- Subsystem States ---
  let notifications = $state([]);
  let alertConfig = $state(null);
  let contextConfig = $state(null);
  let contextUnlocked = $state(false);
  let lockTimeout;
  let inputConfig = $state(null);
  let keyboardMenuConfig = $state(null);
  let progressConfig = $state(null);
  let radialMenuConfig = $state(null);
  let skillCheckConfig = $state(null);
  let tabletConfig = $state(null);
  let textUIs = $state({
    'right-center': null,
    'left-center': null,
    'top-center': null,
    'bottom-center': null
  });

  // --- Notifications Helper ---
  const triggerNotification = (data) => {
    const id = Math.random().toString(36).substring(2, 9);
    const duration = data.duration || 3000;
    const notification = {
      id,
      ...data,
      closing: false
    };
    notifications = [...notifications, notification];
  };

  // --- Message Listener ---
  onMount(() => {
    const handleMessage = (event) => {
      const { action, data } = event.data;

      switch (action) {
        // 1. Notifications
        case 'notify':
          triggerNotification(data);
          break;

        // 2. Alert Dialog
        case 'sendAlert':
          alertConfig = data;
          break;
        case 'closeAlertDialog':
          alertConfig = null;
          break;

        // 3. Clipboard
        case 'setClipboard':
          if (navigator.clipboard) {
            navigator.clipboard.writeText(data);
          } else {
            const el = document.createElement('textarea');
            el.value = data;
            document.body.appendChild(el);
            el.select();
            document.execCommand('copy');
            document.body.removeChild(el);
          }
          break;

        // 4. Context Menu
        case 'showContext':
          if (lockTimeout) {
            clearTimeout(lockTimeout);
            lockTimeout = null;
          }
          contextConfig = data;
          break;
        case 'hideContext':
          contextConfig = null;
          if (lockTimeout) clearTimeout(lockTimeout);
          lockTimeout = setTimeout(() => {
            contextUnlocked = false;
            lockTimeout = null;
          }, 300);
          break;

        // 5. Input Dialog
        case 'openDialog':
          inputConfig = data;
          break;
        case 'closeInputDialog':
          inputConfig = null;
          break;

        // 6. Keyboard Menu
        case 'setMenu':
          keyboardMenuConfig = data;
          break;
        case 'closeMenu':
          keyboardMenuConfig = null;
          break;

        // 7. Progress Bar & Circle
        case 'progress':
          progressConfig = { ...data, type: 'linear' };
          break;
        case 'circleProgress':
          progressConfig = { ...data, type: 'circle' };
          break;
        case 'progressCancel':
          progressConfig = null;
          break;

        // 8. Radial Menu
        case 'openRadialMenu':
          radialMenuConfig = data;
          break;

        // 9. Skill Check
        case 'startSkillCheck':
          skillCheckConfig = data;
          break;
        case 'skillCheckCancel':
          skillCheckConfig = null;
          break;

        // 10. Text UI
        case 'textUi':
          const pos = data.position || 'right-center';
          textUIs = { ...textUIs, [pos]: data };
          break;
        case 'textUiHide':
          textUIs = {
            'right-center': null,
            'left-center': null,
            'top-center': null,
            'bottom-center': null
          };
          break;

        // 11. Tablet UI
        case 'openTablet':
          tabletConfig = {
            active: true,
            tabletId: data.tabletId || 'system_tablet',
            title: data.title || 'OS X-TABLET',
            subtitle: data.subtitle || 'Secure Operations System',
            apps: data.apps || null,
            currentView: 'home',
            activeAppId: null,
            customContent: {}
          };
          break;
        case 'closeTablet':
          tabletConfig = null;
          break;
        case 'openTabletApp':
          if (tabletConfig) {
            tabletConfig.activeAppId = data.appId;
            tabletConfig.currentView = 'app';
          }
          break;
        case 'setTabletAppContent':
          if (tabletConfig) {
            tabletConfig.activeAppId = data.appId;
            tabletConfig.currentView = 'app';
            tabletConfig.customContent = {
              ...tabletConfig.customContent,
              [data.appId]: { title: data.title, html: data.html }
            };
          }
          break;
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  });
</script>

<main class="ox-lib-svelte-hud">
  <!-- Notifications Wrapper -->
  <Notifications bind:notifications />

  <!-- Alert Dialog Modal -->
  {#if alertConfig}
    <AlertDialog {alertConfig} {post} onclose={() => alertConfig = null} />
  {/if}

  <!-- Context Menu (Phone UI) -->
  {#if contextConfig}
    <ContextMenu {contextConfig} {post} bind:contextUnlocked onclose={() => contextConfig = null} />
  {/if}

  <!-- Input Dialog Modal -->
  {#if inputConfig}
    <InputDialog {inputConfig} {post} onclose={() => inputConfig = null} />
  {/if}

  <!-- Keyboard Menu -->
  {#if keyboardMenuConfig}
    <KeyboardMenu {keyboardMenuConfig} {post} onclose={() => keyboardMenuConfig = null} />
  {/if}

  <!-- Progress Bar & Circle -->
  {#if progressConfig}
    {#key progressConfig}
      <Progress {progressConfig} {post} onclose={() => progressConfig = null} />
    {/key}
  {/if}

  <!-- Radial Menu -->
  {#if radialMenuConfig}
    <RadialMenu {radialMenuConfig} {post} onclose={() => radialMenuConfig = null} />
  {/if}

  <!-- Skill Check Overlay -->
  {#if skillCheckConfig}
    <SkillCheck {skillCheckConfig} {post} onclose={() => skillCheckConfig = null} />
  {/if}

  <!-- Tablet NUI Device -->
  {#if tabletConfig}
    <Tablet bind:tabletConfig {post} onclose={() => tabletConfig = null} />
  {/if}

  <!-- Text UI Floating Container -->
  <TextUI {textUIs} />
</main>

<style>
  /* Base wrapper styles */
  .ox-lib-svelte-hud {
    position: relative;
    width: 100vw;
    height: 100vh;
    overflow: hidden;
    pointer-events: none;
  }
</style>
